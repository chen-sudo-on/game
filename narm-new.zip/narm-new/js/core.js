"use strict";

// --- 天气系统 ---
let weatherState = {
    type: 'clear',
    icon: '☀️',
    label: '晴',
    wind: 0,
    temp: null,
    updatedAt: 0
};
let lastWeatherType = 'clear';
let weatherCoords = null;

// 更新天气UI（简化版）
function updateWeatherUI() {
    const w = weatherState || { icon: '☀️', label: '晴' };
    // 天气显示已在 updateEnvironment 中处理
}

// 刷新天气
async function refreshWeather(force = false) {
    const now = Date.now();
    if (!force && weatherState.updatedAt && now - weatherState.updatedAt < 3 * 60 * 1000) return;

    try {
        if (!weatherCoords) {
            weatherCoords = await new Promise((resolve, reject) => {
                if (!navigator.geolocation) return reject(new Error('no_geolocation'));
                navigator.geolocation.getCurrentPosition(
                    (pos) => resolve({ lat: pos.coords.latitude, lon: pos.coords.longitude }),
                    (err) => reject(err),
                    { enableHighAccuracy: false, timeout: 5000, maximumAge: 15 * 60 * 1000 }
                );
            });
        }

        const url = `https://api.open-meteo.com/v1/forecast?latitude=${encodeURIComponent(weatherCoords.lat)}&longitude=${encodeURIComponent(weatherCoords.lon)}&current=temperature_2m,precipitation,rain,snowfall,weather_code,wind_speed_10m&timezone=auto`;
        const res = await fetch(url, { cache: 'no-store' });
        if (!res.ok) throw new Error('weather_fetch_failed');
        const data = await res.json();
        const cur = data && data.current ? data.current : null;
        if (!cur) throw new Error('weather_no_current');

        const wind = Number(cur.wind_speed_10m || 0) || 0;
        const precipitation = Number(cur.precipitation || 0) || 0;
        const rain = Number(cur.rain || 0) || 0;
        const snowfall = Number(cur.snowfall || 0) || 0;
        const code = Number(cur.weather_code || 0) || 0;
        const temp = typeof cur.temperature_2m === 'number' ? cur.temperature_2m : null;

        const wx = mapWeather({ wind, precipitation, rain, snowfall, code });
        setWeatherState({ ...wx, wind, temp, updatedAt: now });
    } catch {
        const wx = fallbackWeather();
        setWeatherState({ ...wx, updatedAt: now });
    }
}

function mapWeather({ wind, precipitation, rain, snowfall, code }) {
    const isSnow = snowfall > 0 || (code >= 71 && code <= 77) || code === 85 || code === 86;
    const isRain = rain > 0 || precipitation > 0 || (code >= 51 && code <= 67) || (code >= 80 && code <= 82) || (code >= 95 && code <= 99);
    const isCloudy = !isSnow && !isRain && (code === 1 || code === 2 || code === 3);
    const isWind = !isSnow && !isRain && wind >= 10;

    if (isSnow) return { type: 'snow', icon: '🌨️', label: '下雪' };
    if (isRain) return { type: 'rain', icon: '🌧️', label: '下雨' };
    if (isWind) return { type: 'wind', icon: '🌬️', label: '大风' };
    if (isCloudy) return { type: 'cloudy', icon: '☁️', label: '多云' };
    return { type: 'clear', icon: '☀️', label: '晴朗' };
}

function fallbackWeather() {
    const now = new Date();
    const hour = now.getHours();
    const seed = Number(`${now.getFullYear()}${now.getMonth() + 1}${now.getDate()}${hour}`);
    const x = Math.abs(Math.sin(seed)) % 1;
    const winter = window.currentSeason === 'winter';
    const summer = window.currentSeason === 'summer';
    if (winter && x > 0.78) return { type: 'snow', icon: '🌨️', label: '下雪' };
    if (!winter && x > 0.82) return { type: 'rain', icon: '🌧️', label: '下雨' };
    if (summer && x > 0.66) return { type: 'wind', icon: '🌬️', label: '大风' };
    if (x > 0.45) return { type: 'cloudy', icon: '☁️', label: '多云' };
    return { type: 'clear', icon: '☀️', label: '晴朗' };
}

function setWeatherState(next) {
    weatherState = { ...weatherState, ...next };

    const body = document.body;
    body.classList.remove('weather-rain', 'weather-snow', 'weather-wind');
    if (weatherState.type === 'rain') body.classList.add('weather-rain');
    if (weatherState.type === 'snow') body.classList.add('weather-snow');
    if (weatherState.type === 'wind') body.classList.add('weather-wind');

    if (weatherState.type !== lastWeatherType) {
        if (weatherState.type === 'rain') {
            applyRainWatering();
            showToast('下雨了：土地被浇湿了', 'success');
        } else if (weatherState.type === 'snow') {
            showToast('下雪了：作物生长变慢');
        } else if (weatherState.type === 'wind') {
            showToast('刮风了：作物生长略慢');
        }
        lastWeatherType = weatherState.type;
    }

    updateEnvironment();
}

function applyRainWatering() {
    const now = Date.now();
    const until = now + getWaterDurationMs();
    for (let i = 0; i < state.farm.length; i++) {
        const c = state.farm[i];
        if (!c) continue;
        if (c.locked) continue;
        if (c.type !== 'tilled') continue;
        c.waterUntil = Math.max(c.waterUntil || 0, until);
    }
    updateFarmVisuals();
}

function getWeatherGrowthMultiplier() {
    if (!weatherState) return 1;
    if (weatherState.type === 'snow') return 0.75;
    if (weatherState.type === 'wind') return 0.9;
    return 1;
}

// --- 核心功能 ---
// 注意：以下核心函数已在 events.js 中定义：
// - onCellClick (地块点击)
// - handleHarvest (收获)
// - tryUnlockLand (解锁土地)
// - buySeed (购买种子)
// - selectTool (选择工具)
// - selectSeed (选择种子)
// - craft (制作)
// - craftFertilizer (制作肥料)
// 此文件仅保留天气系统、游戏循环、酒厂和批量售卖相关逻辑

// --- 游戏循环 (核心逻辑) ---
function gameLoop() {
    const now = Date.now();
    let needsUpdate = false;

    if (weatherState && weatherState.type === 'rain') {
        for (let i = 0; i < state.farm.length; i++) {
            const c = state.farm[i];
            if (!c) continue;
            if (c.locked) continue;
            if (c.type !== 'tilled') continue;
            c.waterUntil = Math.max(c.waterUntil || 0, now + 5000);
        }
    }

    state.farm.forEach((cell, idx) => {
        if (cell.locked) return;
        if (cell.cropId) {
            const crop = CROPS[cell.cropId];
            // 如果作物不存在，清理该地块
            if (!crop) {
                cell.cropId = null;
                cell.progress = 0;
                return;
            }

            const isWatered = cell.waterUntil > now;

            if (!cell.progress) cell.progress = 0;

            if (cell.progress < 100) {
                let increment = (100 / crop.time);
                if (isWatered) increment *= 2;
                if (cell.fertilized) increment *= 1.5;
                if (crop.trait && crop.trait.type === 'speed' && typeof crop.trait.val === 'number') increment *= crop.trait.val;

                // 环境加成
                if (crop.growth_bonus) {
                    if (crop.growth_bonus === 'night' && window.isNight) increment *= 2;
                    if (crop.growth_bonus === 'day' && !window.isNight) increment *= 2;
                }

                if (window.isNight && isCellLit(idx)) increment *= 1.35;

                increment *= getWeatherGrowthMultiplier();

                cell.progress += increment;

                if (cell.progress >= 100) {
                    cell.progress = 100;
                    showToast(`${crop.name} 成熟了！`, "success");
                }
                needsUpdate = true;
            }
        }
    });

    robotHarvestTick();
    buildingTick();
    breweryTick(now);
    ordersTick(now);
    weedGrowTick(now);

    updateFarmVisuals();
}

// 杂草生长计时
function weedGrowTick(now) {
    let grown = 0;
    const growMs = getWeedGrowMs();
    for (let i = 0; i < state.farm.length; i++) {
        const cell = state.farm[i];
        if (!cell) continue;
        if (cell.locked) continue;
        if (cell.cropId) continue;
        if (cell.weed) continue;
        const t0 = typeof cell.emptySince === 'number' ? cell.emptySince : now;
        if (now - t0 >= growMs) {
            cell.weed = true;
            grown++;
            renderFarmCell(i);
        }
    }
    if (grown > 0) showToast(`杂草长出来了：${grown}处`);
}

function getWeedGrowMs() {
    const n = getBuildingCount('fence');
    const slow = Math.min(0.5, n * 0.08);
    return Math.round(WEED.growMs * (1 + slow));
}

// 机器人收割计时
function robotHarvestTick(silent = true, render = true) {
    if (!state.robot || !state.robot.owned) return 0;
    if ((state.robot.energy || 0) <= 0) return 0;

    let harvested = 0;
    state.farm.forEach((cell, idx) => {
        if ((state.robot.energy || 0) <= 0) return;
        if (cell.locked) return;
        if (cell.cropId && (cell.progress || 0) >= 100) {
            handleHarvest(cell, idx);
            state.robot.energy = Math.max(0, (state.robot.energy || 0) - 1);
            harvested++;
            if (render) renderFarmCell(idx);
        }
    });

    if (harvested > 0) {
        if (render) {
            renderInventory();
            renderShop();
        }
        if (!silent) showToast(`机器人收割 ${harvested} 个作物`, 'success');
    }

    return harvested;
}

// 建筑周期 tick
function buildingTick() {
    const now = Date.now();

    if (hasBuilding('compost')) {
        if (!state.buildings.compostNextAt || now >= state.buildings.compostNextAt) {
            state.buildings.compostNextAt = now + 25000;
            const weed = state.inventory.crops.weed || 0;
            if (weed >= 2) {
                state.inventory.crops.weed = weed - 2;
                state.inventory.fertilizer = (state.inventory.fertilizer || 0) + 1;
                renderInventory();
            }
        }
    }

    if (hasBuilding('sprinkler')) {
        if (!state.buildings.sprinklerNextAt || now >= state.buildings.sprinklerNextAt) {
            state.buildings.sprinklerNextAt = now + 5000;
            let applied = 0;
            for (let i = 0; i < state.farm.length; i++) {
                const cell = state.farm[i];
                if (cell.cropId && (cell.progress || 0) < 100) {
                    if ((cell.waterUntil || 0) < now + 2500) {
                        cell.waterUntil = now + 2500;
                        renderFarmCell(i);
                        applied++;
                        if (applied >= 6) break;
                    }
                }
            }
        }
    }
}

// 酿酒周期 tick
function breweryTick(now) {
    // 只在酿酒面板可见时更新
    const recipesTab = document.getElementById('tab-recipes');
    if (!recipesTab || !recipesTab.classList.contains('active')) return;

    const kitchenBrewery = document.getElementById('kitchen-tab-brewery');
    if (!kitchenBrewery || !kitchenBrewery.classList.contains('active')) return;

    KitchenSystem.renderBreweryPanel();
}

// 订单周期 tick
function ordersTick(now) {
    if (!state.orders || typeof state.orders !== 'object') {
        state.orders = { nextRefreshAt: 0, list: [] };
    }
    if (!Array.isArray(state.orders.list)) state.orders.list = [];

    if (!state.orders.nextRefreshAt || state.orders.nextRefreshAt <= 0) {
        state.orders.list = generateOrders(now, ORDERS.count);
        state.orders.nextRefreshAt = now + ORDERS.refreshMs;
        return;
    }

    if (now >= state.orders.nextRefreshAt) {
        state.orders.list = generateOrders(now, ORDERS.count);
        state.orders.nextRefreshAt = now + ORDERS.refreshMs;
        showToast('📦 新订单已刷新', 'success');
        const active = document.getElementById('tab-orders');
        if (active && active.classList.contains('active')) renderOrders();
        state.orders.lastRenderAt = now;
        return;
    }

    const active = document.getElementById('tab-orders');
    if (active && active.classList.contains('active')) {
        const last = typeof state.orders.lastRenderAt === 'number' ? state.orders.lastRenderAt : 0;
        if (now - last >= 1000) {
            state.orders.lastRenderAt = now;
            renderOrders();
        }
    }
}

// 导出游戏循环到全局
window.gameLoop = gameLoop;
window.refreshWeather = refreshWeather;
window.initWeather = initWeather;
window.updateWeatherUI = updateWeatherUI;
window.weedGrowTick = weedGrowTick;
window.getWeedGrowMs = getWeedGrowMs;
window.robotHarvestTick = robotHarvestTick;
window.buildingTick = buildingTick;
window.breweryTick = breweryTick;
window.ordersTick = ordersTick;
window.weatherState = weatherState;
window.lastWeatherType = lastWeatherType;
window.setWeatherState = setWeatherState;
window.applyRainWatering = applyRainWatering;
window.getWeatherGrowthMultiplier = getWeatherGrowthMultiplier;
