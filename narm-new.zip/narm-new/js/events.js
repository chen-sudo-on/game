"use strict";

// --- 事件处理函数 ---

// 点击地块
function onCellClick(idx) {
    const cell = state.farm[idx];
    const now = Date.now();

    if (cell.locked) {
        if (state.tool !== 'hand') {
            showToast('这块地还没解锁，切到👆点击解锁');
            return;
        }
        tryUnlockLand(idx);
        return;
    }

    if (state.buildings && state.buildings.placeMode === 'lamp') {
        if (state.tool !== 'hand') {
            showToast('摆放模式下请使用👆');
            return;
        }
        toggleLampAtCell(idx);
        return;
    }

    // 初始杂草：需先清理
    if (!cell.cropId && cell.weed) {
        if (state.tool === 'scythe') {
            cell.weed = false;
            cell.emptySince = now;
            state.inventory.crops['weed'] = (state.inventory.crops['weed'] || 0) + 1;
            showToast("清理杂草 +1🌿", "success");
            renderInventory();
            renderFarmCell(idx);
            playSound('harvest');
            return;
        }
        if (state.tool === 'basket') {
            let cleared = 0;
            state.farm.forEach((c, i2) => {
                if (!c.cropId && c.weed) {
                    c.weed = false;
                    c.emptySince = now;
                    state.inventory.crops['weed'] = (state.inventory.crops['weed'] || 0) + 1;
                    cleared++;
                }
            });
            if (cleared > 0) {
                showToast(`清理 ${cleared} 处杂草`, "success");
                renderInventory();
                state.farm.forEach((_, i3) => renderFarmCell(i3));
                playSound('harvest');
            }
            return;
        }
        if (state.tool === 'hand') {
            showToast("这里是杂草，使用⚔️清理");
            return;
        }
        showToast("先用⚔️清理杂草");
        return;
    }

    // 1. 锄头
    if (state.tool === 'hoe') {
        if (cell.type === 'wild') {
            cell.type = 'tilled';
            cell.emptySince = now;
            playSound('dig');
            renderFarmCell(idx);
        } else if (cell.cropId) {
            const crop = CROPS[cell.cropId];
            const cropName = crop ? crop.name : '作物';
            if (confirm(`确定要铲除 ${cropName} 吗？`)) {
                cell.cropId = null;
                cell.progress = 0;
                cell.waterUntil = 0;
                cell.fertilized = false;
                cell.harvestCount = 0;
                cell.weed = false;
                cell.emptySince = now;
                renderFarmCell(idx);
                playSound('dig');
            }
        }
    }
    // 2. 播种 (选中种子时覆盖工具)
    else if (state.selectedSeed) {
        if (cell.type === 'tilled' && !cell.cropId) {
            const crop = CROPS[state.selectedSeed];
            if (!crop) {
                showToast('种子不存在');
                state.selectedSeed = null;
                return;
            }
            if (crop.seasons && crop.seasons.length > 0 && !crop.seasons.includes(currentSeason)) {
                showToast(`只能在 ${crop.seasons.map(s => ({
                    'spring': '春', 'summer': '夏', 'autumn': '秋', 'winter': '冬'
                }[s])).join('/')} 种植!`);
                return;
            }

            if (state.inventory.seeds[state.selectedSeed] > 0) {
                state.inventory.seeds[state.selectedSeed]--;
                cell.cropId = state.selectedSeed;
                cell.plantedAt = now;
                cell.progress = 0;
                cell.waterUntil = 0;
                cell.weed = false;
                cell.emptySince = 0;

                if (state.inventory.seeds[state.selectedSeed] === 0) {
                    state.selectedSeed = null;
                    state.tool = 'hand';
                }

                renderInventory();
                updateToolsUI();
                renderFarmCell(idx);
                playSound('plant');
            }
        } else if (cell.type === 'wild') {
            showToast("先开垦土地！");
        }
    }
    // 3. 水壶
    else if (state.tool === 'water') {
        if (cell.type !== 'wild') {
            cell.waterUntil = now + getWaterDurationMs();
            renderFarmCell(idx);
            playSound('water');
        }
    }
    // 4. 镰刀 (收获)
    else if (state.tool === 'scythe') {
        if (cell.cropId && cell.progress >= 100) {
            const msg = handleHarvest(cell, idx);
            showToast(msg, "success");
            renderInventory();
            renderFarmCell(idx);
            playSound('harvest');
        }
    }
    // 5. 施肥
    else if (state.tool === 'fertilizer') {
        if (cell.cropId && (cell.progress || 0) < 100 && !cell.fertilized) {
            if (state.inventory.fertilizer > 0) {
                state.inventory.fertilizer--;
                cell.fertilized = true;
                showToast("施肥成功", "success");
                renderFarmCell(idx);
                updateToolsUI();
            } else {
                showToast("没有肥料了！用杂草制作吧", "normal");
            }
        } else if (cell.fertilized) {
            showToast("已经施过肥了");
        }
    }
    // 6. 收集篮
    else if (state.tool === 'basket') {
        let harvested = 0;
        state.farm.forEach((c, i2) => {
            if (c.cropId && (c.progress || 0) >= 100) {
                handleHarvest(c, i2);
                harvested++;
            }
        });
        if (harvested > 0) {
            showToast(`收集 ${harvested} 个作物`, "success");
            renderInventory();
            state.farm.forEach((_, i3) => renderFarmCell(i3));
            playSound('harvest');
        }
    }
    // 7. 铲子 (移除作物)
    else if (state.tool === 'shovel') {
        if (cell.cropId) {
            const crop = CROPS[cell.cropId];
            const cropName = crop ? crop.name : '作物';
            if (confirm(`确定要铲除 ${cropName} 吗？将获得杂草。`)) {
                cell.cropId = null;
                cell.progress = 0;
                cell.waterUntil = 0;
                cell.fertilized = false;
                cell.harvestCount = 0;
                cell.weed = false;
                cell.emptySince = now;
                state.inventory.crops['weed'] = (state.inventory.crops['weed'] || 0) + 1;
                showToast("获得 1x 杂草");
                renderFarmCell(idx);
                renderInventory();
                playSound('dig');
            }
        } else {
            showToast("这里没有作物");
        }
    }
    // 8. 手 (点击信息)
    else if (state.tool === 'hand') {
        if (cell.cropId) {
            const crop = CROPS[cell.cropId];
            // 如果作物不存在，清理该地块
            if (!crop) {
                cell.cropId = null;
                cell.progress = 0;
                renderFarmCell(idx);
                return;
            }
            let info = "";
            if (cell.progress >= 100) info = "可以收获了！";
            else info = `生长中... (${Math.floor(cell.progress)}%)`;

            if (crop.trait && crop.trait.type === 'regrow') {
                info += ` [收获: ${cell.harvestCount || 0}/${crop.trait.max_harvest}]`;
            }
            showToast(`${crop.name}: ${info}`);
        }
    }
}

// 尝试解锁土地
function tryUnlockLand(idx) {
    const cell = state.farm[idx];
    if (!cell || !cell.locked) return;
    const price = getLandUnlockPrice(idx);
    if (state.coins < price) {
        showToast(`金币不足 💸（需要 ${price} 金）`);
        return;
    }
    const ok = confirm(`解锁这块土地需要 ${price} 金，确定解锁吗？`);
    if (!ok) return;

    state.coins -= price;
    cell.locked = false;
    cell.type = 'wild';
    cell.cropId = null;
    cell.progress = 0;
    cell.waterUntil = 0;
    cell.fertilized = false;
    cell.harvestCount = 0;
    cell.weed = true;
    cell.emptySince = Date.now();

    updateHeader();
    renderFarmCell(idx);
    renderInventory();
    playSound('buy');
    showToast('解锁成功 ✅', 'success');
}

// 处理收获
function handleHarvest(cell, idx) {
    const crop = CROPS[cell.cropId];
    // 如果作物不存在，直接返回
    if (!crop) return;

    state.inventory.crops[cell.cropId] = (state.inventory.crops[cell.cropId] || 0) + 1;

    let msg = `收获 ${crop.name}`;

    const lunarBonus = getLunarCropBonus(cell.cropId);
    if (lunarBonus.active && lunarBonus.yieldExtra > 0) {
        state.inventory.crops[cell.cropId] += lunarBonus.yieldExtra;
        msg += ` (农历旺 +${lunarBonus.yieldExtra})`;
    }

    // 特性：额外收获 (bonus)
    if (crop.trait && crop.trait.type === 'bonus') {
        if (Math.random() < crop.trait.val) {
            state.inventory.crops[cell.cropId]++;
            msg += " (双倍!✨)";
        }
    } else if (Math.random() > 0.9) {
        state.inventory.crops[cell.cropId]++;
        msg += " (好运!✨)";
    }

    // 特性：种子掉落 (seed_drop)
    if (crop.seed_drop) {
        if (Math.random() < crop.seed_drop.chance) {
            const seedCount = Math.floor(Math.random() * (crop.seed_drop.max - crop.seed_drop.min + 1)) + crop.seed_drop.min;
            if (seedCount > 0) {
                state.inventory.seeds[cell.cropId] = (state.inventory.seeds[cell.cropId] || 0) + seedCount;
                msg += ` +${seedCount}种子`;
            }
        }
    }

    // 特性：再生 (regrow)
    if (crop.trait && crop.trait.type === 'regrow') {
        cell.harvestCount = (cell.harvestCount || 0) + 1;
        if (cell.harvestCount >= crop.trait.max_harvest) {
            cell.cropId = null;
            cell.progress = 0;
            cell.waterUntil = 0;
            cell.fertilized = false;
            cell.harvestCount = 0;
            cell.weed = false;
            cell.emptySince = Date.now();
            msg += " (枯萎了)";
        } else {
            cell.progress = crop.trait.val;
            cell.waterUntil = 0;
            cell.weed = false;
            cell.emptySince = 0;
            msg += ` (再生 ${cell.harvestCount}/${crop.trait.max_harvest})`;
        }
    } else {
        cell.cropId = null;
        cell.progress = 0;
        cell.waterUntil = 0;
        cell.fertilized = false;
        cell.harvestCount = 0;
        cell.weed = false;
        cell.emptySince = Date.now();
    }
    return msg;
}

// 选择工具
function selectTool(t) {
    state.tool = t;
    state.selectedSeed = null;
    updateToolsUI();
    renderInventory();
}

// 选择种子
function selectSeed(id) {
    const crop = CROPS[id];
    if (!crop) {
        showToast('种子不存在');
        return;
    }
    state.selectedSeed = id;
    state.tool = 'hand';
    updateToolsUI();
    renderInventory();
    showToast(`选择了 ${crop.name}种子`);
}

// 切换标签页
function switchTab(tabId, tabEl) {
    document.querySelectorAll('.tab').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));

    const activeTab = tabEl || document.querySelector(`.tab[data-tab="${tabId}"]`);
    if (activeTab) activeTab.classList.add('active');

    const activeContent = document.getElementById('tab-' + tabId);
    if (activeContent) activeContent.classList.add('active');

    if (tabId === 'orders') {
        renderOrders();
    }
    if (tabId === 'recipes') {
        // 食谱标签使用 KitchenSystem 处理
        KitchenSystem.switchTab('recipes');
    }
}

// 显示提示
function showToast(msg, type) {
    const div = document.createElement('div');
    div.className = 'toast';
    div.innerText = msg;
    if (type === 'success') div.style.borderLeft = "4px solid #55efc4";
    document.getElementById('toast-container').appendChild(div);

    requestAnimationFrame(() => {
        div.classList.add('show');
    });

    setTimeout(() => {
        div.classList.remove('show');
        setTimeout(() => div.remove(), 300);
    }, 2000);
}

// 切换侧边栏
function toggleSidebar() {
    const panel = document.getElementById('right-panel');
    const btn = document.getElementById('fab-right');
    if (panel && panel.classList.contains('open')) {
        panel.classList.remove('open');
        if (btn) btn.classList.remove('active');
    } else {
        panel.classList.add('open');
        if (btn) btn.classList.add('active');
    }
}

// 切换左侧侧边栏
function toggleLeftSidebar() {
    const panel = document.getElementById('left-panel');
    const btn = document.getElementById('fab-left');
    if (panel && panel.classList.contains('open')) {
        panel.classList.remove('open');
        if (btn) btn.classList.remove('active');
    } else {
        panel.classList.add('open');
        if (btn) btn.classList.add('active');
    }
}

// 买种子
function buySeed(id) {
    const crop = CROPS[id];
    if (!crop) {
        showToast('种子不存在');
        return;
    }
    if (state.coins >= crop.price) {
        state.coins -= crop.price;
        state.inventory.seeds[id] = (state.inventory.seeds[id] || 0) + 1;
        updateHeader();
        renderInventory();
        playSound('buy');
    } else {
        showToast("金币不足 💸");
    }
}

// 买电池
function buyBattery() {
    if (state.coins < SHOP.batteryPrice) {
        showToast('金币不足 💸');
        return;
    }
    state.coins -= SHOP.batteryPrice;
    state.inventory.batteries = (state.inventory.batteries || 0) + 1;
    updateHeader();
    renderInventory();
    renderShop();
    playSound('buy');
}

// 买机器人
function buyRobot() {
    if (state.robot.owned) {
        showToast('你已经拥有机器人了');
        return;
    }
    if (state.coins < SHOP.robotPrice) {
        showToast('金币不足 💸');
        return;
    }
    state.coins -= SHOP.robotPrice;
    state.robot.owned = true;
    state.robot.maxEnergy = SHOP.robotMaxEnergy;
    state.robot.energy = Math.min(state.robot.maxEnergy, Math.max(state.robot.energy || 0, Math.ceil(state.robot.maxEnergy * 0.5)));
    updateHeader();
    renderInventory();
    renderShop();
    showToast('获得 🤖 自动收割机器人', 'success');
    playSound('buy');
}

// 买食谱解锁
function buyRecipeUnlock(index) {
    const r = RECIPES[index];
    if (!r || !r.unlockPrice) return;
    if (r.unlocked) {
        showToast('该食谱已解锁');
        return;
    }
    if (state.coins < r.unlockPrice) {
        showToast('金币不足 💸');
        return;
    }
    state.coins -= r.unlockPrice;
    r.unlocked = true;
    updateHeader();
    KitchenSystem.renderRecipeList();
    renderShop();
    showToast(`解锁食谱：${r.name}`, 'success');
    playSound('buy');
}

// 使用电池
function useBattery() {
    if (!state.robot.owned) {
        showToast('还没有机器人');
        return;
    }
    const n = state.inventory.batteries || 0;
    if (n <= 0) {
        showToast('没有电池了');
        return;
    }
    if ((state.robot.energy || 0) >= state.robot.maxEnergy) {
        showToast('电量已满');
        return;
    }
    state.inventory.batteries = n - 1;
    state.robot.energy = Math.min(state.robot.maxEnergy, (state.robot.energy || 0) + SHOP.batteryCharge);
    renderInventory();
    renderShop();
    showToast(`充电 +${SHOP.batteryCharge}🔋`, 'success');
    playSound('buy');
}

// 买建筑
function buyBuilding(id) {
    const b = BUILDINGS.find(x => x.id === id);
    if (!b) return;
    if (state.coins < b.price) {
        showToast('金币不足 💸');
        return;
    }
    state.coins -= b.price;
    if (b.kind === 'decor') {
        state.buildings.owned[id] = (getBuildingCount(id) || 0) + 1;
    } else {
        if (hasBuilding(id)) {
            showToast('已拥有该建筑');
            state.coins += b.price;
            updateHeader();
            return;
        }
        state.buildings.owned[id] = true;
    }
    updateHeader();
    renderShop();
    renderBuildings();
    renderInventory();
    showToast(`${b.kind === 'decor' ? '购买' : '建造'}完成：${b.emoji} ${b.name}`, 'success');
    playSound('buy');
}

// 制作肥料
function craftFertilizer() {
    if ((state.inventory.crops['weed'] || 0) >= 2) {
        state.inventory.crops['weed'] -= 2;
        state.inventory.fertilizer++;
        renderInventory();
        updateToolsUI();
        showToast("制作了 1x 肥料");
        playSound('craft');
    } else {
        showToast("杂草不足 (需要2个)");
    }
}

// 卖食物
function sellFood(index) {
    const count = state.inventory.foods[index] || 0;
    if (count > 0) {
        state.inventory.foods[index] = count - 1;
        state.coins += Math.round(RECIPES[index].price * getSellMultiplier());
        updateHeader();
        renderInventory();
        playSound('coin');
    }
}

// 卖作物
function sellCrop(id) {
    const crop = CROPS[id];
    if (!crop) {
        showToast('作物不存在');
        return;
    }
    if (state.inventory.crops[id] > 0) {
        state.inventory.crops[id]--;
        const lunarBonus = getLunarCropBonus(id);
        state.coins += Math.round(crop.sell * getSellMultiplier() * (lunarBonus.active ? lunarBonus.sellMul : 1));
        updateHeader();
        renderInventory();
        playSound('coin');
    }
}

// 卖酒
function sellAlcohol(drinkId) {
    const inv = state.inventory.alcohols || {};
    const n = inv[drinkId] || 0;
    if (n <= 0) return;
    const spec = getDrinkSpecByDrinkId(drinkId);
    if (!spec) return;
    inv[drinkId] = n - 1;
    state.coins += Math.round(spec.sell * getSellMultiplier());
    updateHeader();
    renderInventory();
    playSound('coin');
}

// 开始酿造
function startBrewing(slotIndex, cropId) {
    if (!hasBuilding('brewery')) {
        showToast('还没有酿酒桶，去商店买一个');
        return;
    }
    if (!isBrewableCrop(cropId)) {
        showToast('这个作物不太适合拿来酿酒');
        return;
    }
    const spec = getDrinkSpecForCrop(cropId);
    if (!spec) return;

    const slots = (state.brewery && state.brewery.slots) || [];
    const cur = slots[slotIndex] || null;
    if (cur) {
        showToast('这个桶正在使用中');
        return;
    }
    const have = state.inventory.crops[cropId] || 0;
    if (have < spec.cropQty) {
        const crop = CROPS[cropId];
        const cropName = crop ? crop.name : '作物';
        showToast('材料不足：需要 ' + cropName + ' x' + spec.cropQty);
        return;
    }

    state.inventory.crops[cropId] = have - spec.cropQty;
    const now = Date.now();
    slots[slotIndex] = { cropId, cropQty: spec.cropQty, startedAt: now, doneAt: now + spec.brewMs };
    state.brewery.slots = slots;
    renderInventory();
    renderShop();
    playSound('craft');
    showToast('开始酿造：' + spec.emoji + ' ' + spec.name);
}

// 取出酿造的酒
function collectBrew(slotIndex) {
    const slots = (state.brewery && state.brewery.slots) || [];
    const cur = slots[slotIndex] || null;
    if (!cur) return;
    const now = Date.now();
    if ((cur.doneAt || 0) > now) {
        showToast('还没酿好，再等等');
        return;
    }
    const spec = getDrinkSpecForCrop(cur.cropId);
    if (!spec) {
        slots[slotIndex] = null;
        state.brewery.slots = slots;
        KitchenSystem.renderBreweryPanel();
        return;
    }
    const inv = state.inventory.alcohols || {};
    inv[spec.id] = (inv[spec.id] || 0) + 1;
    state.inventory.alcohols = inv;
    slots[slotIndex] = null;
    state.brewery.slots = slots;
    renderInventory();
    playSound('harvest');
    showToast('取出完成：' + spec.emoji + ' ' + spec.name, 'success');
}

// 切换摆放模式
function togglePlaceMode(kind) {
    if (kind !== 'lamp') return;
    if (!hasBuilding('lamp')) {
        showToast('还没有灯笼，去商店购买');
        return;
    }
    if (!state.buildings) return;
    state.buildings.placeMode = state.buildings.placeMode === kind ? null : kind;
    renderBuildings();
    showToast(state.buildings.placeMode ? '点击地块摆放/撤下🏮（不占地）' : '已退出摆放模式');
}

// 切换灯笼位置
function toggleLampAtCell(idx) {
    if (!state.buildings) return;
    if (!state.buildings.placed) state.buildings.placed = { lamp: [] };
    if (!Array.isArray(state.buildings.placed.lamp)) state.buildings.placed.lamp = [];
    const list = state.buildings.placed.lamp;
    const i = list.indexOf(idx);
    const max = getBuildingCount('lamp');
    if (i >= 0) {
        list.splice(i, 1);
        showToast('已撤下🏮');
    } else {
        if (list.length >= max) {
            showToast(`灯笼不够（最多摆放 ${max} 个）`);
            return;
        }
        list.push(idx);
        showToast('已摆放🏮');
    }
    for (let k = 0; k < state.farm.length; k++) renderFarmCell(k);
}

// 初始化
function init() {
    loadAudioSetting();

    const browserSave = localStorage.getItem(SAVE.browserKey);
    if (browserSave) {
        const shouldLoad = SELFTEST.enabled ? true : confirm('检测到浏览器本地存档，是否读取？');
        if (shouldLoad) {
            try {
                applySaveData(JSON.parse(browserSave));
                showToast('已读取本地存档', 'success');
            } catch {
                showToast('本地存档损坏，读取失败');
            }
        }
    }

    // 初始赠送种子：随机5个全季作物
    if (Object.keys(state.inventory.seeds).length === 0) {
        const allSeasonCrops = Object.keys(CROPS).filter(k => CROPS[k].seasons && CROPS[k].seasons.length === 0);
        if (allSeasonCrops.length > 0) {
            for (let i = 0; i < 5; i++) {
                const randomCrop = allSeasonCrops[Math.floor(Math.random() * allSeasonCrops.length)];
                state.inventory.seeds[randomCrop] = (state.inventory.seeds[randomCrop] || 0) + 1;
            }
            showToast("获得新手礼包：5个全季种子！", "success");
        }
    }

    document.documentElement.style.setProperty('--rows', String(CONFIG.rows));
    document.documentElement.style.setProperty('--cols', String(CONFIG.cols));

    // 设置网格布局
    const grid = document.getElementById('farm-grid');
    grid.style.gridTemplateColumns = `repeat(${CONFIG.cols}, var(--cell-size))`;
    grid.style.gridTemplateRows = `repeat(${CONFIG.rows}, var(--cell-size))`;

    // 渲染地块
    state.farm.forEach((_, i) => {
        const cell = document.createElement('div');
        cell.className = 'farm-cell';
        cell.dataset.index = i;
        cell.onclick = () => onCellClick(i);
        cell.onmouseenter = (e) => showCellTooltip(i, e.clientX, e.clientY);
        cell.onmousemove = (e) => showCellTooltip(i, e.clientX, e.clientY);
        cell.onmouseleave = () => hideCellTooltip();
        cell.ontouchstart = (e) => {
            if (e.touches && e.touches[0]) {
                showCellTooltip(i, e.touches[0].clientX, e.touches[0].clientY, true);
            }
        };
        cell.ontouchend = () => hideCellTooltip();

        // 进度容器
        const container = document.createElement('div');
        container.className = 'progress-container';
        container.style.display = 'none';

        const text = document.createElement('div');
        text.className = 'progress-text';

        const bar = document.createElement('div');
        bar.className = 'progress-bar';
        bar.innerHTML = '<div class="progress-fill"></div>';

        container.appendChild(text);
        container.appendChild(bar);
        cell.appendChild(container);

        grid.appendChild(cell);
    });

    // 启动循环
    setInterval(gameLoop, CONFIG.gameLoopInterval);

    setInterval(() => {
        try { autoSaveTick(); } catch {}
    }, 15000);

    window.addEventListener('beforeunload', () => {
        try { autoSaveTick(); } catch {}
    });

    // 环境检测 (每秒更新)
    setInterval(updateEnvironment, 1000);
    updateEnvironment();

    {
        const el = document.getElementById('time-display');
        if (el) {
            el.oncontextmenu = (e) => {
                e.preventDefault();
            };
        }
    }

    initWeather();

    // 初始渲染
    renderAll();
    renderAudioToggle();
    initGuideScroll();
    showToast("✨ 欢迎来到像素农场！");

    // 初始化 GameState
    if (window.GameState && typeof GameState.init === 'function') {
        GameState.init();
    }

    // 初始化 KitchenSystem
    if (window.KitchenSystem && typeof KitchenSystem.init === 'function') {
        KitchenSystem.init();
        KitchenSystem.renderRecipeList();
    }
}

// 全局变量初始化
window.isNight = false;
window.currentSeason = 'spring';

// 导出到全局
window.onCellClick = onCellClick;
window.tryUnlockLand = tryUnlockLand;
window.handleHarvest = handleHarvest;
window.selectTool = selectTool;
window.selectSeed = selectSeed;
window.switchTab = switchTab;
window.showToast = showToast;
window.toggleSidebar = toggleSidebar;
window.toggleLeftSidebar = toggleLeftSidebar;
window.buySeed = buySeed;
window.buyBattery = buyBattery;
window.buyRobot = buyRobot;
window.buyRecipeUnlock = buyRecipeUnlock;
window.useBattery = useBattery;
window.buyBuilding = buyBuilding;
window.craftFertilizer = craftFertilizer;
window.craft = craft;
window.sellFood = sellFood;
window.sellCrop = sellCrop;
window.sellAlcohol = sellAlcohol;
window.startBrewing = startBrewing;
window.collectBrew = collectBrew;
window.togglePlaceMode = togglePlaceMode;
window.toggleLampAtCell = toggleLampAtCell;
window.initGuideScroll = initGuideScroll;
window.initWeather = initWeather;
window.init = init;
