"use strict";

// --- 渲染函数 ---

// 渲染所有
function renderAll() {
    updateHeader();
    updateToolsUI();
    renderShop();
    renderOrders();
    renderInventory();
    KitchenSystem.renderRecipeList();
    renderBuildings();
    state.farm.forEach((_, i) => renderFarmCell(i));
}

// 更新头部显示
function updateHeader() {
    const el = document.getElementById('coins');
    if (el) el.innerText = state.coins;
}

// 更新工具栏 UI
function updateToolsUI() {
    document.querySelectorAll('.tool-btn').forEach(btn => {
        const t = btn.dataset.tool;
        if (!state.selectedSeed && state.tool === t) {
            btn.classList.add('active');
        } else {
            btn.classList.remove('active');
        }
    });

    const currentToolLabel = document.getElementById('current-tool-label');
    if (currentToolLabel) {
        if (state.selectedSeed && CROPS[state.selectedSeed]) {
            currentToolLabel.innerText = `种植${CROPS[state.selectedSeed].name}`;
        } else {
            const toolNames = {
                hand: '查看',
                hoe: '开垦',
                water: '浇水',
                scythe: '收获',
                fertilizer: '施肥',
                basket: '收集',
                shovel: '铲除'
            };
            currentToolLabel.innerText = toolNames[state.tool] || '查看';
        }
    }

    const fertCount = document.getElementById('fert-count');
    if (fertCount) {
        const n = state.inventory.fertilizer || 0;
        fertCount.innerText = n > 0 ? String(n) : '';
        fertCount.style.display = n > 0 ? 'inline-flex' : 'none';
    }
}

// 渲染单个地块 - 优化版：避免完全重建 DOM
function renderFarmCell(idx) {
    const cell = state.farm[idx];
    const el = document.querySelector(`.farm-cell[data-index="${idx}"]`);
    const now = Date.now();

    if (!el) return;

    // 更新基础类名
    let baseClass = 'farm-cell';
    if (cell.locked) baseClass += ' locked';
    if (cell.type === 'tilled') baseClass += ' tilled';
    if (cell.waterUntil > now) baseClass += ' watered';
    if (!cell.cropId && cell.weed) baseClass += ' weedy';
    if (isNight && isCellLit(idx)) baseClass += ' lit';
    el.className = baseClass;

    if (cell.locked) {
        // 锁定地块只更新内容，不重建整个元素
        const overlay = el.querySelector('.lock-overlay') || document.createElement('div');
        overlay.className = 'lock-overlay';
        if (!overlay.innerHTML.includes('lock-icon')) {
            overlay.innerHTML = `
                <div class="lock-icon">&#128274;</div>
                <div class="lock-price">${getLandUnlockPrice(idx)}金</div>
            `;
        }
        if (!el.contains(overlay)) el.appendChild(overlay);
        // 移除其他子元素（progress-container, crop-sprite, lamp-marker）
        const others = el.querySelectorAll('.progress-container, .crop-sprite, .lamp-marker');
        others.forEach(o => o.remove());
        return;
    }

    // 获取或创建 progress-container（保留引用）
    let container = el.querySelector('.progress-container');
    if (!container) {
        container = document.createElement('div');
        container.className = 'progress-container';
        container.style.display = 'none';

        const text = document.createElement('div');
        text.className = 'progress-text';

        const bar = document.createElement('div');
        bar.className = 'progress-bar';
        bar.innerHTML = '<div class="progress-fill"></div>';

        container.appendChild(text);
        container.appendChild(bar);
    }

    // 获取或创建 lamp-marker
    let lampMarker = el.querySelector('.lamp-marker');
    const hasLamp = isLampPlacedAt(idx);
    if (hasLamp && !lampMarker) {
        lampMarker = document.createElement('div');
        lampMarker.className = 'lamp-marker';
        lampMarker.innerText = '🏮';
    }
    if (lampMarker) {
        if (hasLamp) {
            if (!el.contains(lampMarker)) el.appendChild(lampMarker);
        } else {
            lampMarker.remove();
            lampMarker = null;
        }
    }

    // 获取或创建 crop-sprite
    let sprite = el.querySelector('.crop-sprite');
    if (cell.cropId) {
        const crop = CROPS[cell.cropId];
        // 如果作物不存在，清理该地块
        if (!crop) {
            cell.cropId = null;
            cell.progress = 0;
            renderFarmCell(idx);
            return;
        }

        const p = cell.progress || 0;
        let displayEmoji = '';
        if (p >= 100) displayEmoji = crop.emoji;
        else if (p > 50) displayEmoji = '🌿';
        else displayEmoji = '🌱';

        if (!sprite) {
            sprite = document.createElement('div');
            sprite.className = 'crop-sprite';
            el.appendChild(sprite);
        }
        sprite.innerText = displayEmoji;

        if (p < 100) {
            container.style.display = 'flex';
        } else {
            container.style.display = 'none';
        }
    } else if (cell.weed) {
        if (!sprite) {
            sprite = document.createElement('div');
            sprite.className = 'crop-sprite';
            el.appendChild(sprite);
        }
        sprite.innerText = CROPS.weed ? CROPS.weed.emoji : '🌿';
        container.style.display = 'none';
    } else {
        if (sprite) sprite.remove();
        container.style.display = 'none';
    }

    // 确保 container 存在且正确位置
    if (!el.contains(container)) {
        el.appendChild(container);
    }
}

// 更新农场视觉效果（用于游戏循环）- 优化版：只更新有变化的元素
function updateFarmVisuals() {
    const now = Date.now();
    let needsUpdate = false;

    state.farm.forEach((cell, idx) => {
        if (cell.locked) return;

        const el = document.querySelector(`.farm-cell[data-index="${idx}"]`);
        if (!el) return;

        // 更新浇水状态（只更新有变化的）
        if (cell.type !== 'wild') {
            const isWatered = cell.waterUntil > now;
            const hadClass = el.classList.contains('watered');
            if (isWatered !== hadClass) {
                if (isWatered) el.classList.add('watered');
                else el.classList.remove('watered');
            }
        }

        // 处理作物显示
        if (cell.cropId) {
            const crop = CROPS[cell.cropId];
            // 如果作物不存在，清理该地块
            if (!crop) {
                cell.cropId = null;
                cell.progress = 0;
                renderFarmCell(idx);
                needsUpdate = true;
                return;
            }

            const p = Math.max(0, Math.min(100, cell.progress || 0));
            const sprite = el.querySelector('.crop-sprite');
            const container = el.querySelector('.progress-container');
            const text = el.querySelector('.progress-text');
            const fill = el.querySelector('.progress-fill');

            if (!sprite || !container || !text || !fill) {
                // 如果缺失元素，触发完整渲染
                renderFarmCell(idx);
                needsUpdate = true;
                return;
            }

            // 更新作物图标（只在阶段变化时）
            let displayEmoji = '';
            if (p >= 100) displayEmoji = crop.emoji;
            else if (p > 50) displayEmoji = '🌿';
            else displayEmoji = '🌱';

            if (sprite.innerText !== displayEmoji) {
                sprite.innerText = displayEmoji;
            }

            // 更新进度条（只更新有变化的）
            if (p < 100) {
                const fillWidth = Math.round(p);
                if (parseInt(fill.style.width, 10) !== fillWidth) {
                    fill.style.width = fillWidth + '%';
                }
                fill.style.backgroundColor = cell.waterUntil > now ? '#0984e3' : '#00b894';

                // 计算剩余时间
                let baseMultiplier = 1;
                if (cell.fertilized) baseMultiplier *= 1.5;
                if (crop.trait && crop.trait.type === 'speed') baseMultiplier *= crop.trait.val;
                if (crop.growth_bonus) {
                    if (crop.growth_bonus === 'night' && isNight) baseMultiplier *= 2;
                    if (crop.growth_bonus === 'day' && !isNight) baseMultiplier *= 2;
                }

                const baseRate = crop.time > 0 ? (100 / crop.time) * baseMultiplier : 0;
                if (baseRate > 0) {
                    const remainingPercent = 100 - p;
                    const waterRemainingSec = Math.max(0, (cell.waterUntil || 0) - now) / 1000;
                    let remainingSec = 0;
                    if (waterRemainingSec > 0) {
                        const wateredRate = baseRate * 2;
                        const wateredGain = wateredRate * waterRemainingSec;
                        if (remainingPercent <= wateredGain) {
                            remainingSec = remainingPercent / wateredRate;
                        } else {
                            remainingSec = waterRemainingSec + (remainingPercent - wateredGain) / baseRate;
                        }
                    } else {
                        remainingSec = remainingPercent / baseRate;
                    }
                    remainingSec = Math.max(0, Math.ceil(remainingSec));

                    const newText = remainingSec + 's';
                    if (text.innerText !== newText) {
                        text.innerText = newText;
                    }
                }

                if (container.style.display !== 'flex') {
                    container.style.display = 'flex';
                }
            } else {
                if (container.style.display !== 'none') {
                    container.style.display = 'none';
                }
            }
        }
    });
}

// 渲染背包
function renderInventory() {
    const invSummary = document.getElementById('inventory-summary');
    if (invSummary) {
        const seedTotal = Object.values(state.inventory.seeds).reduce((a, b) => a + (b || 0), 0);
        const cropTotal = Object.values(state.inventory.crops).reduce((a, b) => a + (b || 0), 0);
        const foodTotal = Object.values(state.inventory.foods).reduce((a, b) => a + (b || 0), 0);
        const alcoholTotal = Object.values(state.inventory.alcohols || {}).reduce((a, b) => a + (b || 0), 0);
        const fert = state.inventory.fertilizer || 0;
        const batteries = state.inventory.batteries || 0;
        const robotOwned = !!(state.robot && state.robot.owned);
        const robotEnergy = (state.robot && state.robot.energy) || 0;
        const robotMax = (state.robot && state.robot.maxEnergy) || SHOP.robotMaxEnergy;
        const canCharge = robotOwned && batteries > 0 && robotEnergy < robotMax;
        invSummary.innerHTML = `
            <div class="soft-row" style="margin-bottom:10px; padding:10px; border-radius:12px; background:var(--glass-bg); border:1px solid var(--glass-border);">
                <div style="display:flex; align-items:center; gap:8px; color: var(--text-muted); font-size:12px;">
                    <span class="badge" style="background:rgba(9,132,227,0.10); border-color:rgba(9,132,227,0.16);">种子 ${seedTotal}</span>
                    <span class="badge" style="background:rgba(0,184,148,0.10); border-color:rgba(0,184,148,0.16); color:rgba(0,184,148,0.95);">作物 ${cropTotal}</span>
                    <span class="badge" style="background:rgba(253,203,110,0.18); border-color:rgba(211,84,0,0.16); color:rgba(211,84,0,0.9);">料理 ${foodTotal}</span>
                    <span class="badge" style="background:rgba(162,155,254,0.14); border-color:rgba(162,155,254,0.22); color:rgba(108,92,231,0.95);">酒 ${alcoholTotal}</span>
                </div>
                <div style="display:flex; align-items:center; gap:8px;">
                    <span class="badge" style="background:rgba(162,155,254,0.14); border-color:rgba(162,155,254,0.22); color:rgba(108,92,231,0.95);">肥料 ${fert}</span>
                    <span class="badge" style="background:rgba(162,155,254,0.14); border-color:rgba(162,155,254,0.22); color:rgba(108,92,231,0.95);">电池 ${batteries}</span>
                </div>
            </div>

            ${robotOwned ? `
                <div class="soft-row" style="margin-bottom:10px; padding:10px; border-radius:12px; background:var(--glass-bg); border:1px solid var(--glass-border);">
                    <div style="display:flex; align-items:center; gap:10px;">
                        <div style="font-weight:900; color: var(--text-main);">🤖 自动收割</div>
                        <div style="font-size:12px; color: var(--text-muted);">电量 ${robotEnergy}/${robotMax}</div>
                    </div>
                    <button class="btn-soft primary" style="padding:6px 10px; border-radius:12px;" ${canCharge ? '' : 'disabled'} onclick="useBattery()">充电</button>
                </div>
            ` : ''}
        `;
    }

    const seedContainer = document.getElementById('seed-list');
    if (!seedContainer) return;
    seedContainer.innerHTML = '';
    const seeds = sortCropIdsBySeason(Object.keys(state.inventory.seeds));

    let hasItems = false;

    seedContainer.insertAdjacentHTML('beforeend', `<div class="section-title">📦 种子 <span class="muted">点击使用种植</span></div>`);

    seeds.forEach(id => {
        const count = state.inventory.seeds[id];
        if (count > 0) {
            hasItems = true;
            const crop = CROPS[id];
            let lunarBonus = { active: false, yieldExtra: 0, sellMul: 1 };
            try {
                lunarBonus = getLunarCropBonus(id) || lunarBonus;
            } catch (e) {
                // 农历功能不可用，使用默认值
            }
            const div = document.createElement('div');
            div.className = 'list-item';
            div.innerHTML = `
                <div class="item-icon">📦</div>
                <div class="item-details">
                    <div class="item-name">${crop.name}种子 <span class="badge" style="background:rgba(9,132,227,0.10); border-color:rgba(9,132,227,0.16);">${count}</span>${lunarBonus.active ? `<span class="badge" style="background:rgba(253,203,110,0.18); border-color:rgba(211,84,0,0.16); color:rgba(211,84,0,0.9);">农历旺</span>` : ''}</div>
                    <div class="item-sub">${lunarBonus.active ? `本月旺种：收获+${lunarBonus.yieldExtra}｜卖价×${lunarBonus.sellMul}` : `拥有: ${count}`}</div>
                </div>
                <button class="item-action btn-use ${state.selectedSeed === id ? 'active' : ''}"
                    onclick="selectSeed('${id}')">
                    ${state.selectedSeed === id ? '种植中' : '使用'}
                </button>
            `;
            seedContainer.appendChild(div);
        }
    });

    const cropContainer = document.getElementById('crop-list');
    if (!cropContainer) return;
    cropContainer.innerHTML = '';
    cropContainer.insertAdjacentHTML('beforeend', `<div class="section-title">🌾 作物 <span class="muted">可出售/可制作</span></div>`);
    Object.keys(state.inventory.crops).forEach(id => {
        const count = state.inventory.crops[id];
        if (count > 0) {
            hasItems = true;
            const crop = CROPS[id];
            let lunarBonus = { active: false, yieldExtra: 0, sellMul: 1 };
            try {
                lunarBonus = getLunarCropBonus(id) || lunarBonus;
            } catch (e) {
                // 农历功能不可用，使用默认值
            }
            const div = document.createElement('div');
            div.className = 'list-item';
            let extraBtn = '';
            if (id === 'weed') {
                extraBtn = `<button class="item-action btn-use" style="margin-right:5px; background:#a29bfe; color:white;" onclick="craftFertilizer()">制肥(2🌿)</button>`;
            }

            const sellPrice = Math.round(crop.sell * (lunarBonus.active ? lunarBonus.sellMul : 1));
            const batchBtn = count > 1 ? `<button class="btn-batch-sell" onclick="BatchSell.open('${id}')" title="批量售卖">📦 ${count > 9 ? '' : count}</button>` : '';

            div.innerHTML = `
                <div class="item-icon">${crop.emoji}</div>
                <div class="item-details">
                    <div class="item-name">${crop.name} <span class="badge" style="background:rgba(0,184,148,0.10); border-color:rgba(0,184,148,0.16); color:rgba(0,184,148,0.95);">${count}</span>${lunarBonus.active ? `<span class="badge" style="background:rgba(253,203,110,0.18); border-color:rgba(211,84,0,0.16); color:rgba(211,84,0,0.9);">农历旺</span>` : ''}</div>
                    <div class="item-sub">单价: ${crop.sell}金${lunarBonus.active ? `（×${lunarBonus.sellMul}）` : ''}</div>
                </div>
                ${extraBtn}
                ${batchBtn}
                <button class="item-action btn-sell" onclick="sellCrop('${id}')">
                    卖 ${sellPrice}金
                </button>
            `;
            cropContainer.appendChild(div);
        }
    });

    const foodContainer = document.getElementById('food-list');
    if (foodContainer) {
        foodContainer.innerHTML = '';
        foodContainer.insertAdjacentHTML('beforeend', `<div class="section-title">🍳 料理 <span class="muted">来自厨房制作</span></div>`);
        Object.keys(state.inventory.foods).forEach(k => {
            const count = state.inventory.foods[k];
            if (count > 0) {
                hasItems = true;
                const r = RECIPES[k];
                if (!r) return;
                const div = document.createElement('div');
                div.className = 'list-item';
                const batchBtn = count > 1 ? `<button class="btn-batch-sell" onclick="BatchSell.openFood(${k})" title="批量售卖">📦 ${count > 9 ? '' : count}</button>` : '';

                div.innerHTML = `
                    <div class="item-icon">${r.emoji}</div>
                    <div class="item-details">
                        <div class="item-name">${r.name} <span class="badge" style="background:rgba(253,203,110,0.20); border-color:rgba(211,84,0,0.16); color:rgba(211,84,0,0.9);">${count}</span></div>
                        <div class="item-sub">单价: ${r.price}金</div>
                    </div>
                    ${batchBtn}
                    <button class="item-action btn-sell" onclick="sellFood(${k})">
                        卖 ${r.price}金
                    </button>
                `;
                foodContainer.appendChild(div);
            }
        });
    }

    const hasAlcohol = renderAlcoholInventory();
    if (hasAlcohol) hasItems = true;

    if (!hasItems && !hasBuilding('brewery')) {
        seedContainer.innerHTML = '<div style="text-align:center; color:var(--text-muted); padding:20px;">背包空空的</div>';
        cropContainer.innerHTML = '';
        if (foodContainer) foodContainer.innerHTML = '';
        const alcoholContainer = document.getElementById('alcohol-list');
        if (alcoholContainer) alcoholContainer.innerHTML = '';
    }
}

// 渲染酒类库存
function renderAlcoholInventory() {
    const container = document.getElementById('alcohol-list');
    if (!container) return false;
    container.innerHTML = '';
    container.insertAdjacentHTML('beforeend', `<div class="section-title">🍷 酒 <span class="muted">来自酿酒桶</span></div>`);
    const inv = state.inventory.alcohols || {};
    const ids = Object.keys(inv).filter(k => (inv[k] || 0) > 0);
    if (ids.length === 0) {
        container.insertAdjacentHTML('beforeend', `<div style="text-align:center; color:var(--text-muted); padding:10px 0;">还没有酿出酒</div>`);
        return false;
    }
    ids
        .map(id => ({ id, spec: getDrinkSpecByDrinkId(id), count: inv[id] || 0 }))
        .filter(x => x.spec && x.count > 0)
        .sort((a, b) => (Number(b.spec.sell || 0) - Number(a.spec.sell || 0)) || String(a.spec.name || '').localeCompare(String(b.spec.name || ''), 'zh-CN'))
        .forEach(x => {
            const div = document.createElement('div');
            div.className = 'list-item';
            const batchBtn = x.count > 1 ? `<button class="btn-batch-sell" onclick="BatchSell.openAlcohol('${x.id}')" title="批量售卖">📦 ${x.count > 9 ? '' : x.count}</button>` : '';

            div.innerHTML = `
                <div class="item-icon">${x.spec.emoji}</div>
                <div class="item-details">
                    <div class="item-name">${x.spec.name} <span class="badge" style="background:rgba(162,155,254,0.14); border-color:rgba(162,155,254,0.22); color:rgba(108,92,231,0.95);">${x.count}</span></div>
                    <div class="item-sub">单价: ${x.spec.sell}金</div>
                </div>
                ${batchBtn}
                <button class="item-action btn-sell" onclick="sellAlcohol('${x.id}')">
                    卖 ${x.spec.sell}金
                </button>
            `;
            container.appendChild(div);
        });
    return true;
}

// 渲染商店
function renderShop() {
    const container = document.getElementById('shop-list');
    if (!container) return;
    container.innerHTML = '';

    container.insertAdjacentHTML('beforeend', `<div class="section-title">🌱 种子 <span class="muted">购买后可在背包使用</span></div>`);

    const seedIds = sortCropIdsBySeason(
        Object.keys(CROPS).filter(id => {
            const crop = CROPS[id];
            return !!(crop && crop.price && crop.price > 0);
        })
    );

    seedIds.forEach(id => {
        const crop = CROPS[id];

        let traitHtml = '';
        if (crop.seasons && crop.seasons.length > 0) {
            const sIcons = { spring: '🌸', summer: '☀️', autumn: '🍁', winter: '❄️' };
            traitHtml += `<span style="margin-left:5px;">${crop.seasons.map(s => sIcons[s]).join('')}</span>`;
        } else {
            traitHtml += `<span style="margin-left:5px;">♾️</span>`;
        }

        if (crop.trait) {
            let color = '#0984e3';
            if (crop.trait.type === 'bonus') color = '#e17055';
            if (crop.trait.type === 'speed') color = '#00b894';
            traitHtml += `<span style="font-size:10px; background:${color}; color:white; padding:2px 4px; border-radius:4px; margin-left:5px;">${crop.trait.label}</span>`;
        }

        if (crop.growth_bonus) {
            const icon = crop.growth_bonus === 'night' ? '🌙' : '☀️';
            traitHtml += `<span style="font-size:10px; background:#636e72; color:white; padding:2px 4px; border-radius:4px; margin-left:5px;">${icon}加速</span>`;
        }

        const div = document.createElement('div');
        div.className = 'list-item';
        div.innerHTML = `
            <div class="item-icon">${crop.emoji}</div>
            <div class="item-details">
                <div class="item-name">${crop.name}种子${traitHtml}</div>
                <div class="item-sub">${crop.time}秒成熟</div>
            </div>
            <button class="item-action btn-buy" onclick="buySeed('${id}')">
                ${crop.price}金
            </button>
        `;
        container.appendChild(div);
    });

    container.insertAdjacentHTML('beforeend', `<div class="section-title">📜 食谱 <span class="muted">解锁后可在厨房制作</span></div>`);

    const lockedRecipes = RECIPES
        .map((r, idx) => ({ r, idx }))
        .filter(x => x.r && x.r.unlockPrice && !x.r.unlocked);

    if (lockedRecipes.length === 0) {
        container.insertAdjacentHTML('beforeend', `<div style="text-align:center; color:var(--text-muted); padding:10px 0;">已解锁全部食谱</div>`);
    } else {
        lockedRecipes.forEach(({ r, idx }) => {
            const reqStr = Object.keys(r.req).map(k => `${CROPS[k] && CROPS[k].name ? CROPS[k].name : k}x${r.req[k]}`).join(' ');
            const div = document.createElement('div');
            div.className = 'list-item';
            div.innerHTML = `
                <div class="item-icon">${r.emoji}</div>
                <div class="item-details">
                    <div class="item-name">${r.name}</div>
                    <div class="item-sub">材料: ${reqStr}</div>
                </div>
                <button class="item-action btn-buy" onclick="buyRecipeUnlock(${idx})">${r.unlockPrice}金</button>
            `;
            container.appendChild(div);
        });
    }

    container.insertAdjacentHTML('beforeend', `<div class="section-title">🤖 自动化 <span class="muted">离线也会收割</span></div>`);

    {
        const owned = !!state.robot.owned;
        const energy = state.robot.energy || 0;
        const maxEnergy = state.robot.maxEnergy || SHOP.robotMaxEnergy;
        const div = document.createElement('div');
        div.className = 'list-item';
        div.innerHTML = `
            <div class="item-icon">🤖</div>
            <div class="item-details">
                <div class="item-name">自动收割机器人 ${owned ? '<span class="badge" style="background:rgba(0,184,148,0.10); border-color:rgba(0,184,148,0.16); color:rgba(0,184,148,0.95);">已拥有</span>' : ''}</div>
                <div class="item-sub">只会收割成熟作物｜电量 ${energy}/${maxEnergy}</div>
            </div>
            ${owned ? `<button class="item-action btn-buy" onclick="useBattery()">充电</button>` : `<button class="item-action btn-buy" onclick="buyRobot()">${SHOP.robotPrice}金</button>`}
        `;
        container.appendChild(div);
    }

    {
        const n = state.inventory.batteries || 0;
        const div = document.createElement('div');
        div.className = 'list-item';
        div.innerHTML = `
            <div class="item-icon">🔋</div>
            <div class="item-details">
                <div class="item-name">电池 <span class="badge" style="background:rgba(162,155,254,0.14); border-color:rgba(162,155,254,0.22); color:rgba(108,92,231,0.95);">${n}</span></div>
                <div class="item-sub">为机器人充电 +${SHOP.batteryCharge}｜一次性消耗</div>
            </div>
            <button class="item-action btn-buy" onclick="buyBattery()">${SHOP.batteryPrice}金</button>
        `;
        container.appendChild(div);
    }

    container.insertAdjacentHTML('beforeend', `<div class="section-title">🏠 建筑 <span class="muted">会摆在农田旁边</span></div>`);

    BUILDINGS.forEach(b => {
        const owned = hasBuilding(b.id);
        const count = getBuildingCount(b.id);
        const div = document.createElement('div');
        div.className = 'list-item';
        div.innerHTML = `
            <div class="item-icon">${b.emoji}</div>
            <div class="item-details">
                <div class="item-name">${b.name} ${b.kind === 'decor' && count > 0 ? `<span class="badge" style="background:rgba(162,155,254,0.14); border-color:rgba(162,155,254,0.22); color:rgba(108,92,231,0.95);">×${count}</span>` : (owned ? '<span class="badge" style="background:rgba(0,184,148,0.10); border-color:rgba(0,184,148,0.16); color:rgba(0,184,148,0.95);">已拥有</span>' : '')}</div>
                <div class="item-sub">${b.desc || ''}</div>
            </div>
            ${b.kind === 'decor' ? `<button class="item-action btn-buy" onclick="buyBuilding('${b.id}')">${b.price}金</button>` : (owned ? `<button class="item-action btn-buy" disabled>已建造</button>` : `<button class="item-action btn-buy" onclick="buyBuilding('${b.id}')">${b.price}金</button>`)}
        `;
        container.appendChild(div);
    });
}

// 渲染订单
function renderOrders() {
    const container = document.getElementById('order-list');
    if (!container) return;

    const now = Date.now();
    if (!state.orders || typeof state.orders !== 'object') state.orders = { nextRefreshAt: 0, list: [] };
    if (!Array.isArray(state.orders.list)) state.orders.list = [];

    if (!state.orders.nextRefreshAt || state.orders.nextRefreshAt <= 0) {
        state.orders.list = generateOrders(now, ORDERS.count);
        state.orders.nextRefreshAt = now + ORDERS.refreshMs;
    }

    const remainMs = Math.max(0, (state.orders.nextRefreshAt || 0) - now);
    const remainMin = Math.floor(remainMs / 60000);
    const remainSec = Math.floor((remainMs % 60000) / 1000);
    const remainText = `${remainMin}分${String(remainSec).padStart(2, '0')}秒`;

    container.innerHTML = '';
    container.insertAdjacentHTML('beforeend', `<div class="section-title">📦 订单 <span class="muted">每20分钟刷新｜下次：${remainText}</span></div>`);

    const list = state.orders.list || [];
    if (list.length === 0) {
        container.insertAdjacentHTML('beforeend', `<div style="text-align:center; color:var(--text-muted); padding:14px 0;">暂无订单</div>`);
        return;
    }

    list.forEach(o => {
        const ok = canFulfillOrder(o);
        const lines = (o.items || [])
            .map(l => {
                const spec = getOrderLineSpec(l);
                if (!spec) return '';
                const have = getOwnedCountForLine(l);
                const need = l.qty || 0;
                const done = have >= need;
                const s = `${spec.emoji} ${spec.name} x${need}（${have}/${need}）`;
                return `<div class="item-sub" style="margin-top:2px; color:${done ? 'rgba(0,184,148,0.95)' : 'var(--text-muted)'};">${escapeHtml(s)}</div>`;
            })
            .join('');

        const div = document.createElement('div');
        div.className = 'list-item';
        div.innerHTML = `
            <div class="item-icon">📦</div>
            <div class="item-details">
                <div class="item-name">${escapeHtml(o.title)} <span class="badge" style="background:rgba(253,203,110,0.20); border-color:rgba(211,84,0,0.16); color:rgba(211,84,0,0.9);">+${Math.floor(o.reward)}金</span></div>
                ${lines}
            </div>
            <button class="item-action btn-buy" onclick="fulfillOrder('${o.id}')" ${ok ? '' : 'disabled'}>交付</button>
        `;
        container.appendChild(div);
    });
}

// 渲染建筑
function renderBuildings() {
    const el = document.getElementById('building-strip');
    if (!el) return;

    const owned = BUILDINGS.filter(b => hasBuilding(b.id));
    if (owned.length === 0) {
        el.innerHTML = '<div style="grid-column:1/-1; text-align:center; color:var(--text-muted); padding:6px 0;">去商店购买建筑</div>';
        return;
    }

    el.innerHTML = '';
    owned.forEach(b => {
        const count = getBuildingCount(b.id);
        const placing = state.buildings && state.buildings.placeMode === b.id;
        const placedCount = b.id === 'lamp' ? ((state.buildings && state.buildings.placed && Array.isArray(state.buildings.placed.lamp)) ? state.buildings.placed.lamp.length : 0) : 0;
        const div = document.createElement('div');
        div.className = 'building-tile' + (placing ? ' placing' : '');
        div.innerHTML = `
            <div class="building-emoji">${b.emoji}</div>
            <div class="building-name">${b.name}${b.kind === 'decor' && count > 1 ? ` ×${count}` : ''}</div>
            <div class="building-sub">${b.desc || ''}${b.id === 'lamp' && count > 0 ? `（已摆放 ${placedCount}/${count}）` : ''}</div>
            ${b.id === 'lamp' ? `<div class="building-actions"><button class="building-mini-btn" onclick="togglePlaceMode('lamp')">${placing ? '取消' : '摆放'}</button></div>` : ''}
        `;
        el.appendChild(div);
    });
}

// 更新环境显示
function updateEnvironment() {
    const now = new Date();
    const hour = now.getHours();
    const min = now.getMinutes();
    const totalMin = hour * 60 + min;

    const isNightNow = hour < 6 || hour >= 18;
    const timeStr = `${String(hour).padStart(2, '0')}:${String(min).padStart(2, '0')}`;

    // 判断季节
    const month = now.getMonth() + 1;
    const seasonNames = { spring: '春', summer: '夏', autumn: '秋', winter: '冬' };
    let season = '';
    if (month >= 3 && month <= 5) season = 'spring';
    else if (month >= 6 && month <= 8) season = 'summer';
    else if (month >= 9 && month <= 11) season = 'autumn';
    else season = 'winter';

    // 更新全局变量
    window.isNight = isNightNow;
    window.currentSeason = season;

    // 更新显示
    const timeEl = document.getElementById('time-display');
    const w = weatherState || { icon: '☀️', label: '晴' };
    if (timeEl) {
        timeEl.innerHTML = `🕐 ${timeStr}<br><span style="font-size:11px">${isNightNow ? '🌙 夜晚' : '☀️ 白天'} · ${seasonNames[season]} · ${w.icon}${w.label}</span>`;
    }

    // 农历信息
    let lunar = { supported: false, display: '', recommendText: '' };
    try {
        lunar = getLunarInfo(now) || lunar;
    } catch (e) {
        // 农历功能不可用
    }
    const lunarEl = document.getElementById('lunar-display');
    if (lunarEl) {
        if (lunar.supported && lunar.display) {
            lunarEl.innerHTML = `📅 ${lunar.display}<br><span style="font-size:10px; color:var(--text-muted)">${lunar.recommendText || ''}</span>`;
        } else {
            lunarEl.innerHTML = '📅 ' + (lunar.display || '');
        }
    }

    // 更新天气
    updateWeatherUI();

    // 更新 body 类名（用于夜间样式）
    if (isNightNow) {
        document.body.classList.add('time-night');
        document.body.classList.remove('time-day');
    } else {
        document.body.classList.add('time-day');
        document.body.classList.remove('time-night');
    }

    // 更新背景
    if (isNightNow) {
        document.body.style.background = 'linear-gradient(135deg, #2c3e50 0%, #000000 100%)';
    } else {
        document.body.style.background = 'linear-gradient(135deg, #a8e6cf 0%, #dcedc1 50%, #ffd3b6 100%)';
    }
}

// 导出到全局
window.renderAll = renderAll;
window.updateHeader = updateHeader;
window.updateToolsUI = updateToolsUI;
window.renderFarmCell = renderFarmCell;
window.updateFarmVisuals = updateFarmVisuals;
window.renderInventory = renderInventory;
window.renderAlcoholInventory = renderAlcoholInventory;
window.renderShop = renderShop;
window.renderOrders = renderOrders;
window.renderBuildings = renderBuildings;
window.updateEnvironment = updateEnvironment;
