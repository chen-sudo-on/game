"use strict";

// =========================================
// 食谱/厨房系统模块
// =========================================

/**
 * 食谱系统命名空间
 */
const KitchenSystem = {
    // 标签页切换状态
    currentTab: 'recipes',

    /**
     * 初始化食谱系统
     */
    init() {
        console.log('[KitchenSystem] 食谱系统已初始化');
    },

    /**
     * 切换标签页
     */
    switchTab(tabName) {
        this.currentTab = tabName;

        // 更新标签按钮状态
        document.querySelectorAll('.kitchen-tab').forEach(btn => {
            btn.classList.remove('active');
        });
        const activeTab = document.querySelector(`.kitchen-tab[data-tab="${tabName}"]`);
        if (activeTab) activeTab.classList.add('active');

        // 更新面板显示
        document.querySelectorAll('.kitchen-tab-content').forEach(panel => {
            panel.classList.remove('active');
        });
        const activePanel = document.getElementById(`kitchen-tab-${tabName}`);
        if (activePanel) activePanel.classList.add('active');

        // 渲染对应面板
        if (tabName === 'recipes') {
            this.renderRecipeList();
        } else if (tabName === 'brewery') {
            this.renderBreweryPanel();
        }
    },

    /**
     * 获取当前可制作的食谱列表
     */
    getVisibleRecipes() {
        return RECIPES
            .map((r, idx) => ({ r, idx }))
            .filter(x => x.r && (!x.r.unlockPrice || x.r.unlocked));
    },

    /**
     * 检查是否可以制作食谱
     */
    canCraftRecipe(recipe) {
        if (!recipe || !recipe.req) return false;
        for (let ing in recipe.req) {
            if ((state.inventory.crops[ing] || 0) < recipe.req[ing]) return false;
        }
        return true;
    },

    /**
     * 制作食谱
     */
    craft(recipeIndex) {
        const recipe = RECIPES[recipeIndex];
        if (!recipe) {
            showToast('食谱不存在');
            return;
        }

        // 检查是否可以制作
        if (!this.canCraftRecipe(recipe)) {
            showToast('材料不足');
            return;
        }

        // 扣除材料
        for (let ing in recipe.req) {
            state.inventory.crops[ing] -= recipe.req[ing];
        }

        // 添加产物
        state.inventory.foods[recipeIndex] = (state.inventory.foods[recipeIndex] || 0) + 1;

        // 更新界面
        renderInventory();
        this.renderRecipeList();
        playSound('buy');
        showToast(`制作了 ${recipe.name}，已放入背包`);
    },

    /**
     * 渲染食谱列表
     */
    renderRecipeList() {
        const container = document.getElementById('recipe-list');
        if (!container) return;

        container.innerHTML = '';
        const visibleRecipes = this.getVisibleRecipes();

        if (visibleRecipes.length === 0) {
            container.innerHTML = '<div style="text-align:center; color:var(--text-muted); padding:14px 0;">去商店解锁更多食谱</div>';
            return;
        }

        // 按可制作状态排序
        visibleRecipes.sort((a, b) => {
            const ca = this.canCraftRecipe(a.r) ? 0 : 1;
            const cb = this.canCraftRecipe(b.r) ? 0 : 1;
            if (ca !== cb) return ca - cb;
            return a.idx - b.idx;
        });

        visibleRecipes.forEach(({ r, idx }) => {
            const canCraft = this.canCraftRecipe(r);
            const reqStr = Object.keys(r.req).map(k => {
                const cropName = CROPS[k] && CROPS[k].name ? escapeHtml(CROPS[k].name) : escapeHtml(k);
                return `${cropName}x${r.req[k]}`;
            }).join(' ');

            const div = document.createElement('div');
            div.className = 'recipe-item';
            div.innerHTML = `
                <div class="recipe-icon">${escapeHtml(r.emoji)}</div>
                <div class="recipe-info">
                    <div class="recipe-name">${escapeHtml(r.name)}</div>
                    <div class="recipe-req">${reqStr}</div>
                </div>
                <button class="recipe-craft-btn ${canCraft ? '' : 'disabled'}"
                    ${canCraft ? `onclick="KitchenSystem.craft(${idx})"` : 'disabled'}>
                    ${canCraft ? '制作' : '材料不足'}
                </button>
            `;
            container.appendChild(div);
        });
    },

    /**
     * 渲染酿酒面板
     */
    renderBreweryPanel() {
        const container = document.getElementById('brewery-list');
        if (!container) return;

        // 确保酿酒状态存在
        if (!state.brewery) {
            state.brewery = { slots: [] };
        }
        if (!Array.isArray(state.brewery.slots)) {
            state.brewery.slots = [];
        }

        container.innerHTML = '';

        if (!hasBuilding('brewery')) {
            container.innerHTML = '<div style="text-align:center; color:var(--text-muted); padding:14px 0;">去商店购买酿酒桶</div>';
            return;
        }

        const now = Date.now();
        const slots = state.brewery.slots || [];
        container.insertAdjacentHTML('beforeend', `<div class="section-title">🍺 酿酒桶 <span class="muted">时间比较久</span></div>`);

        for (let i = 0; i < slots.length; i++) {
            const s = slots[i];
            const div = document.createElement('div');
            div.className = 'brewery-item';

            if (!s) {
                const options = Object.keys(state.inventory.crops || {})
                    .filter(id => isBrewableCrop(id))
                    .map(id => {
                        const spec = getDrinkSpecForCrop(id);
                        const have = state.inventory.crops[id] || 0;
                        if (!spec) return null;
                        if (have < spec.cropQty) return null;
                        return { id, spec, have };
                    })
                    .filter(Boolean)
                    .sort((a, b) => (Number(b.spec.sell || 0) - Number(a.spec.sell || 0)) || String(a.spec.name || '').localeCompare(String(b.spec.name || ''), 'zh-CN'));

                const selectId = `brew-slot-${i}-select`;
                const optHtml = options.length
                    ? options.map(o => {
                        const cropName = CROPS[o.id] ? CROPS[o.id].name : '未知作物';
                        return `<option value="${o.id}">${cropName} x${o.spec.cropQty} → ${o.spec.name}</option>`;
                    }).join('')
                    : `<option value="">没有可用材料</option>`;

                div.innerHTML = `
                    <div class="brewery-icon">🪵</div>
                    <div class="brewery-info">
                        <div class="brewery-name">桶位 ${i + 1} <span class="badge" style="background:rgba(9,132,227,0.10); border-color:rgba(9,132,227,0.16);">空闲</span></div>
                        <div class="brewery-sub">
                            <select id="${selectId}" style="width:100%; padding:6px 8px; border-radius:10px; border:1px solid rgba(0,0,0,0.08); background:rgba(255,255,255,0.8);">
                                ${optHtml}
                            </select>
                        </div>
                    </div>
                    <button class="brewery-action-btn ${options.length ? '' : 'disabled'}" ${options.length ? '' : 'disabled'} onclick="startBrewing(${i}, document.getElementById('${selectId}').value)">
                        开始
                    </button>
                `;
                container.appendChild(div);
                continue;
            }

            const spec = getDrinkSpecForCrop(s.cropId);
            const remainSec = Math.max(0, Math.ceil(((s.doneAt || 0) - now) / 1000));
            const ready = remainSec <= 0;
            const cropName = CROPS[s.cropId] ? CROPS[s.cropId].name : '未知作物';

            div.innerHTML = `
                <div class="brewery-icon">${spec ? spec.emoji : '🍶'}</div>
                <div class="brewery-info">
                    <div class="brewery-name">${spec ? spec.name : '酿造中'} ${ready ? '<span class="badge" style="background:rgba(0,184,148,0.10); border-color:rgba(0,184,148,0.16); color:rgba(0,184,148,0.95);">已完成</span>' : '<span class="badge" style="background:rgba(253,203,110,0.20); border-color:rgba(211,84,0,0.16); color:rgba(211,84,0,0.9);">酿造中</span>'}</div>
                    <div class="brewery-sub">${cropName} x${s.cropQty || 0} ${ready ? '可以取出了' : `剩余 ${remainSec}s`}</div>
                </div>
                <button class="brewery-action-btn" onclick="collectBrew(${i})" ${ready ? '' : 'disabled'}>取出</button>
            `;
            container.appendChild(div);
        }
    },

    /**
     * 刷新面板（供外部调用）
     */
    refresh() {
        if (this.currentTab === 'recipes') {
            this.renderRecipeList();
        } else if (this.currentTab === 'brewery') {
            this.renderBreweryPanel();
        }
    }
};

// 挂载到全局
window.KitchenSystem = KitchenSystem;
window.craft = function(recipeIndex) { KitchenSystem.craft(recipeIndex); };
