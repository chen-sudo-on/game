"use strict";

// --- 工具函数 ---

// 存档管理
function saveToBrowser() {
    autoSaveTick();
    showToast('已保存到浏览器', 'success');
}

function loadFromBrowser() {
    const raw = localStorage.getItem(SAVE.browserKey);
    if (!raw) {
        showToast('没有找到浏览器存档');
        return;
    }
    try {
        applySaveData(JSON.parse(raw));
        renderAll();
        updateFarmVisuals();
        showToast('已读取浏览器存档', 'success');
    } catch {
        showToast('浏览器存档损坏，读取失败');
    }
}

function exportSaveFile() {
    const data = buildSaveData();
    const str = JSON.stringify(data, null, 2);
    const blob = new Blob([str], { type: 'application/json' });
    const a = document.createElement('a');
    const now = new Date();
    const pad = (n) => String(n).padStart(2, '0');
    const name = `pixel-farm-save-${now.getFullYear()}${pad(now.getMonth()+1)}${pad(now.getDate())}-${pad(now.getHours())}${pad(now.getMinutes())}${pad(now.getSeconds())}.json`;
    a.href = URL.createObjectURL(blob);
    a.download = name;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(a.href);
    showToast('已导出存档文件', 'success');
}

function triggerImportSaveFile() {
    const input = document.getElementById('save-file-input');
    if (!input) return;
    input.value = '';
    input.click();
}

function handleImportFile(file) {
    const reader = new FileReader();
    reader.onload = () => {
        try {
            const data = JSON.parse(String(reader.result || ''));
            applySaveData(data);
            renderAll();
            updateFarmVisuals();
            showToast('导入成功', 'success');
        } catch {
            showToast('导入失败：不是有效存档');
        }
    };
    reader.readAsText(file);
}

function resetSave() {
    const ok = confirm('确定要重置存档吗？这会清空浏览器存档并刷新游戏。');
    if (!ok) return;
    localStorage.removeItem(SAVE.browserKey);
    location.reload();
}

// Tooltip 函数
let tooltipHideTimer = null;

function showCellTooltip(idx, clientX, clientY, isTouch = false) {
    const el = document.getElementById('cell-tooltip');
    if (!el) return;

    if (tooltipHideTimer) {
        clearTimeout(tooltipHideTimer);
        tooltipHideTimer = null;
    }

    const c = state.farm[idx];
    let title = '';
    let sub = '';

    if (c.locked) {
        title = '🔒 未解锁土地';
        sub = `点击解锁：${getLandUnlockPrice(idx)}金`;
    }
    else if (c.cropId) {
        const crop = CROPS[c.cropId];
        const p = Math.max(0, Math.min(100, c.progress || 0));
        title = `${crop.emoji} ${crop.name}`;

        if (p >= 100) sub = '已成熟：可收获';
        else sub = `生长中：${Math.floor(p)}%`;

        const tags = [];
        if (c.waterUntil > Date.now()) tags.push('已浇水');
        if (c.fertilized) tags.push('已施肥');
        if (isNight && isCellLit(idx)) tags.push('灯光');
        if (getLunarCropBonus(c.cropId).active) tags.push('农历旺');
        if (crop.trait && crop.trait.type === 'regrow') {
            tags.push(`收获：${c.harvestCount || 0}/${crop.trait.max_harvest}`);
        }
        if (tags.length) sub += `（${tags.join(' / ')}）`;
    } else if (c.weed) {
        title = `${CROPS.weed.emoji} 杂草`;
        sub = '用⚔️清理（或🧺一键清理）';
    } else {
        if (c.type === 'tilled') {
            title = '🟫 已开垦土地';
            sub = '可以播种';
        } else {
            title = '🟨 荒地';
            sub = '用⛏️开垦';
        }
    }

    el.innerHTML = `<div class="tt-title">${escapeHtml(title)}</div><div class="tt-sub">${escapeHtml(sub)}</div>`;
    el.style.display = 'block';
    el.classList.add('show');

    const margin = 12;
    const { innerWidth: vw, innerHeight: vh } = window;
    const rect = el.getBoundingClientRect();
    let x = clientX + 14;
    let y = clientY + 14;
    if (x + rect.width + margin > vw) x = vw - rect.width - margin;
    if (y + rect.height + margin > vh) y = vh - rect.height - margin;
    if (x < margin) x = margin;
    if (y < margin) y = margin;
    el.style.left = `${x}px`;
    el.style.top = `${y}px`;

    if (isTouch) {
        tooltipHideTimer = setTimeout(() => hideCellTooltip(), 1200);
    }
}

function hideCellTooltip() {
    const el = document.getElementById('cell-tooltip');
    if (!el) return;
    if (tooltipHideTimer) {
        clearTimeout(tooltipHideTimer);
        tooltipHideTimer = null;
    }
    el.classList.remove('show');
    el.style.display = 'none';
}

function escapeHtml(str) {
    return String(str)
        .replaceAll('&', '&amp;')
        .replaceAll('<', '&lt;')
        .replaceAll('>', '&gt;')
        .replaceAll('"', '&quot;')
        .replaceAll("'", '&#39;');
}

// 农历相关函数 - 独立实现，不依赖浏览器Intl支持
const LUNAR_MONTH_NAMES = ['','正月','二月','三月','四月','五月','六月','七月','八月','九月','十月','冬月','腊月'];
const LUNAR_DAY_NAMES = [
    '',
    '初一','初二','初三','初四','初五','初六','初七','初八','初九','初十',
    '十一','十二','十三','十四','十五','十六','十七','十八','十九','二十',
    '廿一','廿二','廿三','廿四','廿五','廿六','廿七','廿八','廿九','三十'
];

// 备用农历数据 - 2025年农历
const LUNAR_2025_DATA = [
    { month: 1, startDay: 29, days: 29 },  // 正月从1月29日开始
    { month: 2, startDay: 57, days: 30 },  // 二月
    { month: 3, startDay: 87, days: 29 },  // 三月
    { month: 4, startDay: 116, days: 30 }, // 四月
    { month: 5, startDay: 146, days: 29 }, // 五月
    { month: 6, startDay: 175, days: 30 }, // 六月
    { month: 7, startDay: 205, days: 29 }, // 七月
    { month: 8, startDay: 234, days: 30 }, // 八月
    { month: 9, startDay: 264, days: 29 }, // 九月
    { month: 10, startDay: 293, days: 30 },// 十月
    { month: 11, startDay: 323, days: 29 },// 冬月
    { month: 12, startDay: 352, days: 30 } // 腊月
];

function getLunarDateFallback(date) {
    const year = date.getFullYear();
    const month = date.getMonth() + 1;
    const day = date.getDate();

    if (year === 2025) {
        // 计算是当年的第几天 (从0开始)
        const startOfYear = new Date(year, 0, 1);
        const dayOfYear = Math.floor((date - startOfYear) / 86400000);

        for (const m of LUNAR_2025_DATA) {
            if (dayOfYear >= m.startDay && dayOfYear < m.startDay + m.days) {
                return {
                    month: m.month,
                    day: dayOfYear - m.startDay + 1
                };
            }
        }
    }

    // 默认返回公历月份和日期
    return { month, day };
}

const LUNAR_BONUS_BY_MONTH = {
    1: { crops: ['wheat','strawberry','cabbage'], sellMul: 1.20, yieldExtra: 1 },
    2: { crops: ['bamboo','radish','lettuce'], sellMul: 1.20, yieldExtra: 1 },
    3: { crops: ['tea_bush','rose','pea'], sellMul: 1.18, yieldExtra: 1 },
    4: { crops: ['garlic','onion','kale'], sellMul: 1.18, yieldExtra: 1 },
    5: { crops: ['rice','mint','basil'], sellMul: 1.18, yieldExtra: 1 },
    6: { crops: ['watermelon','melon','cucumber'], sellMul: 1.20, yieldExtra: 1 },
    7: { crops: ['corn','tomato','pepper'], sellMul: 1.18, yieldExtra: 1 },
    8: { crops: ['grape','apple','cranberry'], sellMul: 1.20, yieldExtra: 1 },
    9: { crops: ['pumpkin','sweet_potato','yam'], sellMul: 1.18, yieldExtra: 1 },
    10: { crops: ['mushroom','bok_choy','rye'], sellMul: 1.18, yieldExtra: 1 },
    11: { crops: ['potato','winter_root','spinach'], sellMul: 1.18, yieldExtra: 1 },
    12: { crops: ['crystal_fruit','cactus','ancient_fruit'], sellMul: 1.25, yieldExtra: 1 }
};

let lunarCache = { key: null, info: null };

function getLunarInfo(date = new Date()) {
    const key = date.toDateString();
    if (lunarCache.key === key && lunarCache.info) return lunarCache.info;

    // 使用备用农历计算
    const lunarDate = getLunarDateFallback(date);

    const lunarMonth = lunarDate.month;
    const lunarDay = lunarDate.day;

    const monthName = LUNAR_MONTH_NAMES[lunarMonth] || `${lunarMonth}月`;
    const dayName = LUNAR_DAY_NAMES[lunarDay] || `${lunarDay}`;
    const display = `${monthName}${dayName}`;

    const monthBonus = LUNAR_BONUS_BY_MONTH[lunarMonth] || null;
    const recIds = monthBonus ? monthBonus.crops : [];
    const recNames = recIds
        .filter(id => CROPS[id])
        .slice(0, 3)
        .map(id => `${CROPS[id].emoji}${CROPS[id].name}`);
    const recommendText = monthBonus ? `${recNames.join(' ')}（收获+${monthBonus.yieldExtra}｜卖价×${monthBonus.sellMul}）` : '无';

    const info = {
        supported: true,
        lunarMonth,
        lunarDay,
        isLeapMonth: false,
        display,
        monthBonus,
        recommendText
    };

    lunarCache = { key, info };
    return info;
}

function getLunarCropBonus(cropId) {
    const lunar = getLunarInfo(new Date());
    if (!lunar.supported || !lunar.monthBonus) return { active: false, yieldExtra: 0, sellMul: 1 };
    const active = lunar.monthBonus.crops.includes(cropId);
    return {
        active,
        yieldExtra: active ? (lunar.monthBonus.yieldExtra || 0) : 0,
        sellMul: active ? (lunar.monthBonus.sellMul || 1) : 1
    };
}

// 酿酒相关工具函数
function getDrinkSpecForCrop(cropId) {
    const crop = CROPS[cropId];
    if (!crop) return null;
    const kind = getBrewKind(cropId);
    if (!kind) return null;

    const inputCount = getBrewInputCount(cropId);
    const baseMsByKind = {
        beer: 8 * 60 * 1000,
        wine: 15 * 60 * 1000,
        whiskey: 22 * 60 * 1000,
        vodka: 18 * 60 * 1000,
        rum: 20 * 60 * 1000,
        sake: 16 * 60 * 1000,
        shochu: 18 * 60 * 1000,
        liqueur: 12 * 60 * 1000
    };
    const multByKind = {
        beer: 1.8,
        wine: 2.4,
        whiskey: 3.0,
        vodka: 2.6,
        rum: 2.8,
        sake: 2.5,
        shochu: 2.6,
        liqueur: 2.2
    };
    const emojiByKind = {
        beer: '🍺',
        wine: '🍷',
        whiskey: '🥃',
        vodka: '🥃',
        rum: '🥃',
        sake: '🍶',
        shochu: '🍶',
        liqueur: '🥃'
    };
    const baseMs = baseMsByKind[kind] || (12 * 60 * 1000);
    const scale = Math.min(2.5, 1 + (Number(crop.sell || 0) || 0) / 300);
    const brewMs = Math.max(60 * 1000, Math.round(baseMs * scale));

    let name = '';
    if (cropId === 'grape') name = '葡萄酒';
    else if (cropId === 'apple') name = '苹果酒';
    else if (cropId === 'rice') name = '清酒';
    else if (cropId === 'hops') name = '啤酒';
    else if (cropId === 'potato') name = '伏特加';
    else if (cropId === 'sugarcane') name = '朗姆酒';
    else if (cropId === 'rye') name = '黑麦威士忌';
    else if (cropId === 'corn') name = '玉米威士忌';
    else if (kind === 'wine') name = crop.name + '果酒';
    else if (kind === 'beer') name = crop.name + '啤酒';
    else if (kind === 'whiskey') name = crop.name + '威士忌';
    else if (kind === 'vodka') name = crop.name + '伏特加';
    else if (kind === 'rum') name = crop.name + '朗姆';
    else if (kind === 'sake') name = crop.name + '清酒';
    else if (kind === 'shochu') name = crop.name + '烧酒';
    else if (kind === 'liqueur') name = crop.name + '利口酒';
    else name = crop.name + '酒';

    const sell = Math.max(1, Math.round((Number(crop.sell || 0) || 0) * inputCount * (multByKind[kind] || 2)));
    return {
        id: getDrinkIdForCrop(cropId),
        cropId,
        cropQty: inputCount,
        kind,
        name,
        emoji: emojiByKind[kind] || '🍶',
        brewMs,
        sell
    };
}

function getDrinkSpecByDrinkId(drinkId) {
    if (typeof drinkId !== 'string') return null;
    if (!drinkId.startsWith('brew:')) return null;
    const cropId = drinkId.slice('brew:'.length);
    return getDrinkSpecForCrop(cropId);
}

function isBrewableCrop(cropId) {
    if (!cropId || !CROPS[cropId]) return false;
    if (cropId === 'weed' || cropId === 'bamboo') return false;
    return (
        BREW.fruit.has(cropId) ||
        BREW.grain.has(cropId) ||
        BREW.starchy.has(cropId) ||
        BREW.herb.has(cropId) ||
        cropId === 'sugarcane'
    );
}

function getBrewKind(cropId) {
    if (!isBrewableCrop(cropId)) return null;
    if (cropId === 'rice') return 'sake';
    if (cropId === 'potato') return 'vodka';
    if (cropId === 'sugarcane') return 'rum';
    if (cropId === 'rye' || cropId === 'corn') return 'whiskey';
    if (cropId === 'hops' || BREW.grain.has(cropId)) return 'beer';
    if (BREW.fruit.has(cropId)) return 'wine';
    if (BREW.starchy.has(cropId)) return 'shochu';
    if (BREW.herb.has(cropId)) return 'liqueur';
    return null;
}

function getBrewInputCount(cropId) {
    const crop = CROPS[cropId];
    if (!crop) return 5; // 默认值
    const s = Number(crop.sell) || 0;
    if (s >= 1000) return 1;
    if (s >= 200) return 2;
    if (s >= 80) return 3;
    return 5;
}

function getDrinkIdForCrop(cropId) {
    return `brew:${cropId}`;
}

// 排序相关
function getCropSeasonBucket(crop) {
    if (!crop) return 2;
    const seasons = Array.isArray(crop.seasons) ? crop.seasons : [];
    if (seasons.length === 0) return 1;
    return seasons.includes(currentSeason) ? 0 : 2;
}

function sortCropIdsBySeason(ids) {
    return ids
        .filter(id => CROPS[id])
        .slice()
        .sort((a, b) => {
            const ca = CROPS[a];
            const cb = CROPS[b];
            const ba = getCropSeasonBucket(ca);
            const bb = getCropSeasonBucket(cb);
            if (ba !== bb) return ba - bb;
            const pa = Number(ca.price || 0) || 0;
            const pb = Number(cb.price || 0) || 0;
            if (pa !== pb) return pa - pb;
            return String(ca.name || a).localeCompare(String(cb.name || b), 'zh-CN');
        });
}

// 随机数
function randInt(min, max) {
    const a = Math.ceil(min);
    const b = Math.floor(max);
    return Math.floor(a + Math.random() * (b - a + 1));
}

// 指南滚动
const guideScrollState = {
    timer: 0,
    paused: false,
    lastUserAt: 0
};

function initGuideScroll() {
    const el = document.getElementById('guide-scroll');
    if (!el) return;

    if (guideScrollState.timer) {
        try { clearInterval(guideScrollState.timer); } catch {}
    }

    const pause = () => { guideScrollState.paused = true; };
    const resume = () => { guideScrollState.paused = false; };
    const user = () => { guideScrollState.lastUserAt = Date.now(); };

    el.addEventListener('mouseenter', pause);
    el.addEventListener('mouseleave', resume);
    el.addEventListener('focusin', pause);
    el.addEventListener('focusout', resume);
    el.addEventListener('wheel', user, { passive: true });
    el.addEventListener('touchstart', pause, { passive: true });
    el.addEventListener('touchend', resume, { passive: true });
    el.addEventListener('scroll', user, { passive: true });
    el.addEventListener('pointerdown', pause, { passive: true });
    el.addEventListener('pointerup', resume, { passive: true });

    guideScrollState.timer = setInterval(() => {
        try {
            if (guideScrollState.paused) return;
            if (Date.now() - guideScrollState.lastUserAt < 2500) return;
            if (el.scrollHeight <= el.clientHeight + 2) return;

            const next = el.scrollTop + 1;
            const max = el.scrollHeight - el.clientHeight;
            if (next >= max - 1) {
                el.scrollTop = 0;
            } else {
                el.scrollTop = next;
            }
        } catch {}
    }, 40);
}

// 天气初始化
function initWeather() {
    refreshWeather(true);
    setInterval(() => {
        try { refreshWeather(false); } catch {}
    }, 10 * 60 * 1000);
    document.addEventListener('visibilitychange', () => {
        if (!document.hidden) {
            try { refreshWeather(false); } catch {}
        }
    });
}

// --- 订单系统函数 ---
function canCraftRecipe(recipe) {
    if (!recipe || !recipe.req) return false;
    for (let ing in recipe.req) {
        if ((state.inventory.crops[ing] || 0) < recipe.req[ing]) return false;
    }
    return true;
}

function getOrderLineSpec(line) {
    if (!line || typeof line !== 'object') return null;
    if (line.type === 'food') {
        const idx = Number(line.key);
        const r = Number.isFinite(idx) ? RECIPES[idx] : null;
        if (!r) return null;
        return { type: 'food', key: String(idx), name: r.name, emoji: r.emoji, unit: r.price };
    }
    if (line.type === 'alcohol') {
        const spec = getDrinkSpecByDrinkId(line.key);
        if (!spec) return null;
        return { type: 'alcohol', key: spec.id, name: spec.name, emoji: spec.emoji, unit: spec.sell };
    }
    const crop = CROPS[line.key];
    if (!crop) return null;
    return { type: 'crop', key: line.key, name: crop.name, emoji: crop.emoji, unit: crop.sell };
}

function getOwnedCountForLine(line) {
    const spec = getOrderLineSpec(line);
    if (!spec) return 0;
    if (spec.type === 'food') return state.inventory.foods[spec.key] || 0;
    if (spec.type === 'alcohol') return (state.inventory.alcohols || {})[spec.key] || 0;
    return state.inventory.crops[spec.key] || 0;
}

function canFulfillOrder(order) {
    if (!order || !Array.isArray(order.items)) return false;
    for (const line of order.items) {
        const have = getOwnedCountForLine(line);
        const need = line.qty || 0;
        if (have < need) return false;
    }
    return true;
}

function fulfillOrder(orderId) {
    const orders = state.orders && Array.isArray(state.orders.list) ? state.orders.list : [];
    const order = orders.find(o => o && o.id === orderId);
    if (!order) return;
    if (!canFulfillOrder(order)) {
        showToast('材料不足，无法交付');
        return;
    }

    for (const line of order.items) {
        const spec = getOrderLineSpec(line);
        if (!spec) continue;
        if (spec.type === 'food') {
            state.inventory.foods[spec.key] = Math.max(0, (state.inventory.foods[spec.key] || 0) - line.qty);
        } else if (spec.type === 'alcohol') {
            const inv = state.inventory.alcohols || {};
            inv[spec.key] = Math.max(0, (inv[spec.key] || 0) - line.qty);
            state.inventory.alcohols = inv;
        } else {
            state.inventory.crops[spec.key] = Math.max(0, (state.inventory.crops[spec.key] || 0) - line.qty);
        }
    }

    state.coins += Math.max(1, Math.floor(order.reward));
    state.orders.list = orders.filter(o => o && o.id !== orderId);

    updateHeader();
    renderInventory();
    renderShop();
    renderOrders();
    playSound('coin');
    showToast(`交付完成 +${Math.floor(order.reward)}金`, 'success');
}

function computeLineQty(unit) {
    const u = Number(unit || 0) || 0;
    if (u <= 0) return 1;
    if (u < 20) return randInt(8, 12);
    if (u < 50) return randInt(5, 8);
    if (u < 100) return randInt(3, 5);
    if (u < 200) return randInt(2, 4);
    if (u < 600) return randInt(1, 2);
    return 1;
}

function generateOrders(now, count) {
    const result = [];
    const cropPool = Object.keys(CROPS).filter(id => id && id !== 'weed');
    const foodPool = RECIPES
        .map((r, idx) => ({ r, idx }))
        .filter(x => x.r && (!x.r.unlockPrice || x.r.unlocked))
        .map(x => x.idx);
    const alcoholPool = Object.keys(state.inventory.alcohols || {}).filter(k => (state.inventory.alcohols[k] || 0) > 0);

    for (let i = 0; i < count; i++) {
        const lines = [];
        const wantLines = randInt(1, 2);

        for (let k = 0; k < wantLines; k++) {
            let type = 'crop';
            if (k === 1 && foodPool.length > 0 && Math.random() < 0.6) type = 'food';
            if (k === 0 && foodPool.length > 0 && Math.random() < 0.22) type = 'food';
            if (alcoholPool.length > 0 && Math.random() < 0.10) type = 'alcohol';

            if (type === 'food') {
                if (foodPool.length === 0) continue;
                const idx = foodPool[Math.floor(Math.random() * foodPool.length)];
                const r = RECIPES[idx];
                if (!r) continue;
                const qty = computeLineQty(r.price);
                lines.push({ type: 'food', key: String(idx), qty });
            } else if (type === 'alcohol') {
                if (alcoholPool.length === 0) continue;
                const key = alcoholPool[Math.floor(Math.random() * alcoholPool.length)];
                const spec = getDrinkSpecByDrinkId(key);
                if (!spec) continue;
                const qty = computeLineQty(spec.sell);
                lines.push({ type: 'alcohol', key, qty });
            } else {
                const id = cropPool[Math.floor(Math.random() * cropPool.length)];
                const c = CROPS[id];
                if (!c) continue;
                const qty = computeLineQty(c.sell);
                lines.push({ type: 'crop', key: id, qty });
            }
        }

        if (lines.length === 0) continue;

        const reward = lines.reduce((sum, line) => {
            const spec = getOrderLineSpec(line);
            if (!spec) return sum;
            return sum + (spec.unit || 0) * (line.qty || 1) * 1.2;
        }, 0);

        const firstLineSpec = getOrderLineSpec(lines[0]);
        const title = lines.length === 1 ? '收购' + (firstLineSpec && firstLineSpec.name ? firstLineSpec.name : '物品') : '杂货订单';
        result.push({ id: `order_${now}_${i}`, title, items: lines, reward });
    }

    return result;
}

// 导出到全局
window.sortCropIdsBySeason = sortCropIdsBySeason;
window.canCraftRecipe = canCraftRecipe;
window.getOrderLineSpec = getOrderLineSpec;
window.getOwnedCountForLine = getOwnedCountForLine;
window.canFulfillOrder = canFulfillOrder;
window.fulfillOrder = fulfillOrder;
window.generateOrders = generateOrders;
window.getLunarInfo = getLunarInfo;
window.getLunarCropBonus = getLunarCropBonus;
window.escapeHtml = escapeHtml;
window.randInt = randInt;
window.initGuideScroll = initGuideScroll;
window.initWeather = initWeather;
window.saveToBrowser = saveToBrowser;
window.loadFromBrowser = loadFromBrowser;
window.exportSaveFile = exportSaveFile;
window.triggerImportSaveFile = triggerImportSaveFile;
window.handleImportFile = handleImportFile;
window.resetSave = resetSave;
window.getDrinkSpecForCrop = getDrinkSpecForCrop;
window.getDrinkSpecByDrinkId = getDrinkSpecByDrinkId;
window.isBrewableCrop = isBrewableCrop;
window.getBrewKind = getBrewKind;
