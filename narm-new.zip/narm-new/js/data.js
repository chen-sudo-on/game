"use strict";

// ============================================
// 数据定义
// ============================================

// 注意：CROPS 数据已迁移到 js/data/crops.js
// 该文件会自动在 data.js 之前加载，所以 CROPS 在此处已可用

// 酿酒分类数据
const BREW = {
    slotCount: 3,
    fruit: new Set([
        'strawberry','blueberry','cranberry','apple','grape','mango','pineapple','starfruit',
        'melon','watermelon','banana','orange','peach','cherry','lemon','coconut','cactus','crystal_fruit',
        'ancient_fruit','gem_berry'
    ]),
    grain: new Set(['wheat','barley','oat','rye','rice','corn','sesame']),
    starchy: new Set(['potato','sweet_potato','yam','pumpkin','winter_root']),
    herb: new Set(['hops','mint','basil','rosemary','tea_bush','coffee','cacao','rose','clover'])
};

// 食谱数据 (20+ 种)
const RECIPES = [
    { name: "面包", emoji: "🍞", price: 70, req: { wheat: 3 } },
    { name: "玉米汤", emoji: "🥣", price: 90, req: { corn: 3 } },
    { name: "蔬菜沙拉", emoji: "🥗", price: 100, req: { lettuce: 2, tomato: 1 } },
    { name: "薯条", emoji: "🍟", price: 140, req: { potato: 3 } },
    { name: "番茄酱", emoji: "🥫", price: 140, req: { tomato: 3 } },
    { name: "草莓酱", emoji: "🍯", price: 180, req: { strawberry: 2 } },
    { name: "水果拼盘", emoji: "🍧", price: 430, req: { apple: 1, banana: 1, grape: 1 } },
    { name: "南瓜派", emoji: "🥧", price: 570, req: { pumpkin: 2, wheat: 1 } },
    { name: "披萨", emoji: "🍕", price: 210, req: { wheat: 2, tomato: 2, onion: 1 } },
    { name: "汉堡", emoji: "🍔", price: 120, req: { wheat: 2, lettuce: 1, tomato: 1 } },
    { name: "辣味炖菜", emoji: "🥘", price: 230, req: { pepper: 2, eggplant: 1, potato: 1 } },
    { name: "果汁", emoji: "🍹", price: 400, req: { orange: 2, lemon: 1 } },
    { name: "西瓜汁", emoji: "🥤", price: 450, req: { watermelon: 2 } },
    { name: "蘑菇汤", emoji: "🍲", price: 1130, req: { mushroom: 2 } },
    { name: "烤玉米", emoji: "🌽", price: 60, req: { corn: 2 } },
    { name: "三明治", emoji: "🥪", price: 80, req: { wheat: 2, lettuce: 1 } },
    { name: "腌黄瓜", emoji: "🥒", price: 170, req: { cucumber: 3 } },
    { name: "洋葱圈", emoji: "🧅", price: 240, req: { onion: 3, wheat: 1 } },
    { name: "玫瑰茶", emoji: "🍵", price: 900, req: { rose: 2 } },
    { name: "菠萝炒饭", emoji: "🍛", price: 360, req: { pineapple: 1, wheat: 2, carrot: 1 } },
    { name: "桃子果酱", emoji: "🍑", price: 240, req: { peach: 2 } },
    { name: "樱桃派", emoji: "🥧", price: 280, req: { cherry: 2, wheat: 1 } },
    { name: "甜瓜冰沙", emoji: "🍧", price: 410, req: { melon: 2 } },
    { name: "花束", emoji: "💐", price: 1260, req: { sunflower: 2, rose: 1 } },
    { name: "混合果汁", emoji: "🍹", price: 450, req: { peach: 1, cherry: 1, melon: 1 } },
    { name: "薄荷茶", emoji: "🍵", price: 110, req: { mint: 2 } },
    { name: "香草烤鱼", emoji: "🍖", price: 190, req: { basil: 1, rosemary: 1 } },
    { name: "芝麻团", emoji: "🍘", price: 210, req: { sesame: 2, wheat: 1 } },
    { name: "燕麦粥", emoji: "🥣", price: 360, req: { oat: 2, coconut: 1 } },
    { name: "大麦面包", emoji: "🍞", price: 220, req: { barley: 2, wheat: 1 } },
    { name: "亚麻沙拉", emoji: "🥗", price: 260, req: { flax: 2, lettuce: 1 } },
    { name: "三叶草蜜饮", emoji: "🍹", price: 250, req: { clover: 2 } },
    { name: "椰子奶", emoji: "🥥", price: 360, req: { coconut: 2 } },
    { name: "热可可", emoji: "🍫", price: 720, req: { cacao: 2, coconut: 1 } },
    { name: "可可蛋糕", emoji: "🍰", price: 590, req: { cacao: 2, wheat: 2 } },
    { name: "薄荷巧克力", emoji: "🍫", price: 380, req: { mint: 2, cacao: 1 } },
    { name: "椰香燕麦饼", emoji: "🍪", price: 360, req: { oat: 2, coconut: 1 } },
    { name: "罗勒汤", emoji: "🥣", price: 210, req: { basil: 2, tomato: 1 } },
    { name: "迷迭香面包", emoji: "🍞", price: 250, req: { rosemary: 2, wheat: 2 } },
    { name: "可可薄荷饮", emoji: "🍹", price: 510, req: { mint: 1, cacao: 1, coconut: 1 } },
    { name: "星辰奶昔", emoji: "🥤", price: 2500, req: { starfruit: 2, coconut: 1 }, unlockPrice: 3200, unlocked: false },
    { name: "上古果酿", emoji: "🍷", price: 3600, req: { ancient_fruit: 1 }, unlockPrice: 5200, unlocked: false },
    { name: "宝石果挞", emoji: "🥧", price: 5200, req: { gem_berry: 1, wheat: 2 }, unlockPrice: 8800, unlocked: false },
    { name: "可可咖啡", emoji: "☕", price: 1800, req: { cacao: 1, coffee: 1 }, unlockPrice: 2600, unlocked: false },
    { name: "扬州炒饭", emoji: "🍚", price: 320, req: { rice: 2, carrot: 1, pea: 1, onion: 1 } },
    { name: "蒜蓉菠菜", emoji: "🥬", price: 210, req: { spinach: 2, garlic: 1 } },
    { name: "清炒小白菜", emoji: "🥬", price: 180, req: { bok_choy: 2, garlic: 1 } },
    { name: "酸辣土豆丝", emoji: "🥔", price: 240, req: { potato: 2, pepper: 1, garlic: 1 } },
    { name: "鱼香茄子", emoji: "🍆", price: 360, req: { eggplant: 2, pepper: 1, garlic: 1 } },
    { name: "竹笋蘑菇煲", emoji: "🍲", price: 820, req: { bamboo: 1, mushroom: 1, garlic: 1 } },
    { name: "葱油饼", emoji: "🫓", price: 260, req: { wheat: 2, onion: 1, sesame: 1 } },
    { name: "麻辣卷心菜", emoji: "🥬", price: 260, req: { cabbage: 2, pepper: 1, garlic: 1 } },
    { name: "腊八粥", emoji: "🥣", price: 420, req: { rice: 2, oat: 1, barley: 1, cranberry: 1 } },
    { name: "玫瑰花茶", emoji: "🍵", price: 520, req: { tea_bush: 1, rose: 1 } },
    { name: "地三鲜", emoji: "🥘", price: 520, req: { potato: 1, eggplant: 1, pepper: 1 } },
    { name: "凉拌黄瓜", emoji: "🥒", price: 160, req: { cucumber: 2, garlic: 1 } },
    { name: "香菇白菜", emoji: "🥬", price: 420, req: { cabbage: 2, mushroom: 1, garlic: 1 } },
    { name: "竹笋炒小白菜", emoji: "🥬", price: 360, req: { bamboo: 1, bok_choy: 2, garlic: 1 } },
    { name: "西红柿炖土豆", emoji: "🍲", price: 380, req: { tomato: 2, potato: 1, onion: 1 } },
    { name: "蒜香茄子", emoji: "🍆", price: 320, req: { eggplant: 2, garlic: 1 } },
    { name: "青椒炒饭", emoji: "🍚", price: 280, req: { rice: 2, pepper: 1, onion: 1 } },
    { name: "南瓜粥", emoji: "🥣", price: 340, req: { rice: 2, pumpkin: 1 } },
    { name: "菌菇粥", emoji: "🥣", price: 520, req: { rice: 2, mushroom: 1, onion: 1 } },
    { name: "红薯饼", emoji: "🥞", price: 360, req: { sweet_potato: 2, wheat: 1, sesame: 1 } },
    { name: "芝麻酱拌面", emoji: "🍜", price: 420, req: { wheat: 2, sesame: 2, cucumber: 1 } },
    { name: "酸辣小白菜", emoji: "🥬", price: 260, req: { bok_choy: 2, pepper: 1, garlic: 1 } },
    { name: "胡萝卜炒豌豆", emoji: "🥕", price: 260, req: { carrot: 2, pea: 2 } },
    { name: "玉米豌豆丁", emoji: "🌽", price: 280, req: { corn: 2, pea: 2, carrot: 1 } },
    { name: "白萝卜炖蘑菇", emoji: "🍲", price: 560, req: { radish: 2, mushroom: 1, garlic: 1 } },
    { name: "葱烧茄子", emoji: "🍆", price: 380, req: { eggplant: 2, onion: 2, garlic: 1 } },
    { name: "清炒羽衣甘蓝", emoji: "🥬", price: 240, req: { kale: 2, garlic: 1 } },
    { name: "香辣茄子土豆", emoji: "🥘", price: 460, req: { eggplant: 1, potato: 1, pepper: 2 } },
    { name: "醋溜土豆片", emoji: "🥔", price: 260, req: { potato: 2, onion: 1, garlic: 1 } },
    { name: "蒜蓉竹笋", emoji: "🎍", price: 280, req: { bamboo: 2, garlic: 1 } }
];
