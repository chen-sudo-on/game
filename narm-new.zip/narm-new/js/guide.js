/**
 * 新手引导系统 (Tutorial Manager)
 * 使用事件监听机制，不修改任何全局函数
 */
(function() {
    'use strict';

    // ============================================
    // 私有状态
    // ============================================
    let currentStep = 0;
    let isActive = false;
    let tutorialCompleted = false;
    let highlightRect = null;
    let cleanupFns = []; // 存储事件清理函数
    let initCalled = false; // 防止重复初始化

    // 引导步骤配置
    const STEPS = [
        {
            // Step 1: 点击土地
            id: 'click-land',
            text: '欢迎来到你的农场 🌱\n点击一块土地开始种植吧！',
            target: () => getClickableLand(),
            setup: setupStep0
        },
        {
            // Step 2: 种植作物
            id: 'plant-crop',
            text: '选择种子进行种植。',
            target: () => getSeedButtons(),
            position: 'bottom',
            setup: setupStep1
        },
        {
            // Step 3: 等待成熟并收获
            id: 'harvest-crop',
            text: '等待作物成熟，然后点击收获金币 💰',
            target: () => getHarvestableCell(),
            position: 'bottom',
            setup: setupStep2
        },
        {
            // Step 4: 引导完成
            id: 'complete',
            text: '太棒了！继续解锁更多土地吧 🎉',
            isComplete: true
        }
    ];

    // ============================================
    // DOM 元素
    // ============================================
    let overlay, highlight, tooltip, tooltipText;

    // ============================================
    // 公共接口
    // ============================================
    window.TutorialManager = {
        init: initTutorial,
        start: startTutorial,
        hide: hideTutorial,
        reset: resetTutorial,
        getStatus: getStatus,
        isActive: () => isActive,
        currentStep: () => currentStep
    };

    // ============================================
    // 初始化
    // ============================================
    function initTutorial() {
        // 防止重复初始化
        if (initCalled) return;
        initCalled = true;

        // 检查是否已完成引导
        const saved = localStorage.getItem('pixel-farm-tutorial-completed');
        if (saved === 'true') return;

        createDOM();
        waitForDOMReady().then(() => {
            startTutorial();
        });
    }

    function startTutorial() {
        if (isActive) return;

        isActive = true;
        currentStep = 0;

        // 确保 DOM 已创建
        if (!overlay) {
            createDOM();
        }

        overlay.style.display = 'block';

        // 清除之前的事件监听
        cleanupAll();

        showStep(0);
    }

    function hideTutorial() {
        isActive = false;
        cleanupAll();

        if (overlay) {
            overlay.style.display = 'none';
        }

        // 清理高亮框的所有状态
        if (highlight) {
            highlight.classList.remove('visible', 'complete');
        }
    }

    function resetTutorial() {
        localStorage.removeItem('pixel-farm-tutorial-completed');
        tutorialCompleted = false;
        initCalled = false;
        isActive = false;
        currentStep = 0;
        hideTutorial();
    }

    function getStatus() {
        return {
            isActive,
            currentStep,
            tutorialCompleted
        };
    }

    // ============================================
    // 步骤管理
    // ============================================
    function showStep(stepIndex) {
        if (stepIndex < 0 || stepIndex >= STEPS.length) return;

        // 隐藏高亮（如果有）
        if (highlight) {
            highlight.classList.remove('visible');
        }

        // 检查是否是完成步骤
        const step = STEPS[stepIndex];
        if (step.isComplete) {
            showCompleteStep();
            return;
        }

        currentStep = stepIndex;

        // 安全检查
        if (!tooltipText) return;

        // 更新提示文字
        tooltipText.textContent = step.text;

        // 高亮目标
        if (step.target) {
            highlightTarget(step.target());
        } else {
            hideHighlight();
        }

        // 设置当前步骤的事件监听
        if (step.setup) {
            step.setup();
        }

        // 定位气泡
        positionTooltip(step);
    }

    function showCompleteStep() {
        currentStep = STEPS.length - 1;

        if (!tooltipText) return;
        tooltipText.textContent = STEPS[currentStep].text;

        // 添加完成样式（不需要显示高亮框，只需移除 visible 类）
        if (highlight) {
            highlight.classList.remove('visible', 'complete');
        }

        // 定位气泡
        positionTooltip(STEPS[currentStep]);

        // 2秒后关闭
        setTimeout(() => {
            if (highlight) {
                highlight.classList.remove('complete');
            }
            hideTutorial();
            if (typeof showToast === 'function') {
                showToast('🎉 新手引导完成！开始你的农场之旅吧！', 'success');
            }
        }, 2000);
    }

    function nextStep() {
        if (currentStep < STEPS.length - 1) {
            // 先清理当前步骤的事件监听
            cleanupAll();
            showStep(currentStep + 1);
        }
    }

    // ============================================
    // Step 0: 点击土地 - 使用事件委托监听土地点击
    // ============================================
    function setupStep0() {
        // 自动开垦第一块土地
        ensureFirstLandTilled();

        // 监听土地点击（使用事件委托）
        const landClickHandler = function(e) {
            if (!isActive || currentStep !== 0) return;

            const cellEl = e.target.closest('.farm-cell');
            if (!cellEl) return;

            const idx = parseInt(cellEl.dataset.index, 10);
            if (isNaN(idx) || !state.farm || !state.farm[idx]) return;

            const cell = state.farm[idx];

            // 只处理未锁定的土地
            if (cell.locked) return;

            // 如果是荒地，自动开垦
            if (cell.type === 'wild') {
                cell.type = 'tilled';
                if (typeof renderFarmCell === 'function') {
                    renderFarmCell(idx);
                }
            }

            // 推进到下一步
            setTimeout(() => {
                if (isActive && currentStep === 0) {
                    nextStep();
                }
            }, 150);
        };

        document.addEventListener('click', landClickHandler);
        cleanupFns.push(() => {
            document.removeEventListener('click', landClickHandler);
        });
    }

    // ============================================
    // Step 1: 种植作物 - 监听种子按钮点击
    // ============================================
    function setupStep1() {
        // 监听种子按钮点击
        const seedClickHandler = function(e) {
            if (!isActive || currentStep !== 1) return;

            const target = e.target;
            const seedList = document.getElementById('seed-list');
            const shopList = document.getElementById('shop-list');

            // 检查是否点击了种子相关区域
            if ((seedList && seedList.contains(target)) ||
                (shopList && shopList.contains(target))) {

                // 检查是否有种子被选中
                setTimeout(() => {
                    if (isActive && currentStep === 1 && state.selectedSeed) {
                        nextStep();
                    }
                }, 100);
            }
        };

        // 监听背包区域
        const seedList = document.getElementById('seed-list');
        if (seedList) {
            seedList.addEventListener('click', seedClickHandler);
            cleanupFns.push(() => {
                seedList.removeEventListener('click', seedClickHandler);
            });
        }

        // 监听商店区域
        const shopList = document.getElementById('shop-list');
        if (shopList) {
            shopList.addEventListener('click', seedClickHandler);
            cleanupFns.push(() => {
                shopList.removeEventListener('click', seedClickHandler);
            });
        }
    }

    // ============================================
    // Step 2: 等待收获 - 轮询检测作物成熟
    // ============================================
    let harvestPollTimer = null;
    let originalRenderInventory = null;

    function setupStep2() {
        // 确保 originalRenderInventory 只保存一次
        if (originalRenderInventory === null && typeof window.renderInventory === 'function') {
            originalRenderInventory = window.renderInventory;
        }

        // 监听镰刀/收集篮点击
        const harvestHandler = function(e) {
            if (!isActive || currentStep !== 2) return;

            const target = e.target;
            const cellEl = target.closest('.farm-cell');

            // 如果直接点击了成熟作物
            if (cellEl) {
                const idx = parseInt(cellEl.dataset.index, 10);
                if (isNaN(idx) || !state.farm || !state.farm[idx]) return;

                const cell = state.farm[idx];
                if (cell && cell.cropId && cell.progress >= 100) {
                    setTimeout(() => {
                        // 检查作物是否已被收获
                        if (isActive && currentStep === 2 && (!cell || !cell.cropId)) {
                            completeTutorial();
                        }
                    }, 200);
                }
            }
        };

        document.addEventListener('click', harvestHandler);
        cleanupFns.push(() => {
            document.removeEventListener('click', harvestHandler);
        });

        // 包装 renderInventory
        if (originalRenderInventory && !window.renderInventory._wrappedForTutorial) {
            const wrapped = function() {
                // 调用原始函数
                originalRenderInventory.apply(this, arguments);

                // 检查是否完成收获
                if (!isActive || currentStep !== 2) return;

                const cropList = document.getElementById('crop-list');
                if (cropList && cropList.children.length > 0) {
                    setTimeout(() => {
                        if (isActive && currentStep === 2) {
                            completeTutorial();
                        }
                    }, 500);
                }
            };
            wrapped._wrappedForTutorial = true;
            window.renderInventory = wrapped;

            cleanupFns.push(() => {
                window.renderInventory = originalRenderInventory;
            });
        }
    }

    function completeTutorial() {
        tutorialCompleted = true;
        localStorage.setItem('pixel-farm-tutorial-completed', 'true');

        // 清理事件监听
        cleanupAll();

        // 显示完成步骤
        showCompleteStep();
    }

    // ============================================
    // 清理所有事件监听
    // ============================================
    function cleanupAll() {
        cleanupFns.forEach(fn => {
            try {
                fn();
            } catch (e) {
                // 忽略清理错误
            }
        });
        cleanupFns = [];

        // 清理轮询 timer
        if (harvestPollTimer) {
            clearInterval(harvestPollTimer);
            harvestPollTimer = null;
        }
    }

    // ============================================
    // DOM 工具函数
    // ============================================
    function getClickableLand() {
        if (!state.farm || state.farm.length === 0) return null;

        for (let i = 0; i < state.farm.length; i++) {
            const cell = state.farm[i];
            if (!cell.locked) {
                const el = document.querySelector(`.farm-cell[data-index="${i}"]`);
                if (el) return el;
            }
        }
        return null;
    }

    function getSeedButtons() {
        const seedList = document.getElementById('seed-list');
        if (seedList) {
            const btn = seedList.querySelector('.shop-item, .item-btn, button');
            if (btn) return btn;
        }

        const shopList = document.getElementById('shop-list');
        if (shopList) {
            const btn = shopList.querySelector('.shop-item, .item-btn, button');
            if (btn) return btn;
        }

        return null;
    }

    function getHarvestableCell() {
        if (!state.farm || state.farm.length === 0) return null;

        for (let i = 0; i < state.farm.length; i++) {
            const cell = state.farm[i];
            if (cell.cropId && cell.progress >= 100) {
                const el = document.querySelector(`.farm-cell[data-index="${i}"]`);
                if (el) return el;
            }
        }

        return null;
    }

    function ensureFirstLandTilled() {
        if (!state.farm) return;

        for (let i = 0; i < state.farm.length; i++) {
            const cell = state.farm[i];
            if (!cell.locked && cell.type === 'wild') {
                cell.type = 'tilled';
                if (typeof renderFarmCell === 'function') {
                    renderFarmCell(i);
                }
                break;
            }
        }
    }

    // ============================================
    // DOM 操作
    // ============================================
    function createDOM() {
        // 遮罩层
        overlay = document.createElement('div');
        overlay.id = 'tutorial-overlay';
        overlay.className = 'tutorial-overlay';
        overlay.style.display = 'none';
        overlay.style.pointerEvents = 'none'; // 关键：允许点击穿透遮罩层

        // 高亮框
        highlight = document.createElement('div');
        highlight.id = 'tutorial-highlight';
        highlight.className = 'tutorial-highlight';
        highlight.style.pointerEvents = 'none'; // 关键：允许点击穿透高亮框
        overlay.appendChild(highlight);

        // 提示气泡
        tooltip = document.createElement('div');
        tooltip.id = 'tutorial-tooltip';
        tooltip.className = 'tutorial-tooltip';
        tooltip.innerHTML = `
            <div class="tutorial-arrow"></div>
            <div class="tutorial-content">
                <div class="tutorial-text" id="tutorial-text"></div>
            </div>
        `;
        overlay.appendChild(tooltip);

        document.body.appendChild(overlay);

        tooltipText = document.getElementById('tutorial-text');
    }

    function highlightTarget(target) {
        if (!highlight) return;

        if (!target) {
            hideHighlight();
            return;
        }

        const rect = target.getBoundingClientRect();
        const padding = 8;

        highlight.style.left = `${rect.left - padding}px`;
        highlight.style.top = `${rect.top - padding}px`;
        highlight.style.width = `${rect.width + padding * 2}px`;
        highlight.style.height = `${rect.height + padding * 2}px`;

        highlight.classList.add('visible');
        highlightRect = rect;
    }

    function hideHighlight() {
        if (!highlight) return;
        highlight.classList.remove('visible');
        highlightRect = null;
    }

    function positionTooltip(step) {
        if (!tooltip) return;

        const padding = 12;
        let targetRect = highlightRect;

        if (step.target) {
            const target = step.target();
            if (target) {
                targetRect = target.getBoundingClientRect();
            }
        }

        if (!targetRect) {
            tooltip.style.left = '50%';
            tooltip.style.top = '20%';
            tooltip.style.transform = 'translateX(-50%)';
            return;
        }

        const tooltipRect = tooltip.getBoundingClientRect();
        let top, left;

        // 默认在下方
        top = targetRect.bottom + padding;
        left = targetRect.left + (targetRect.width - tooltipRect.width) / 2;

        if (top + tooltipRect.height > window.innerHeight) {
            top = targetRect.top - tooltipRect.height - padding;
        }

        left = Math.max(padding, Math.min(left, window.innerWidth - tooltipRect.width - padding));
        top = Math.max(padding, Math.min(top, window.innerHeight - tooltipRect.height - padding));

        tooltip.style.left = `${left}px`;
        tooltip.style.top = `${top}px`;
        tooltip.style.transform = '';
    }

    // ============================================
    // DOM 就绪检测
    // ============================================
    function waitForDOMReady() {
        return new Promise((resolve) => {
            const check = () => {
                const grid = document.getElementById('farm-grid');
                const hasCells = grid && grid.querySelectorAll('.farm-cell').length > 0;
                return { grid, hasCells };
            };

            const { grid, hasCells } = check();

            if (hasCells) {
                requestAnimationFrame(resolve);
                return;
            }

            const observer = new MutationObserver(() => {
                const { hasCells } = check();
                if (hasCells) {
                    observer.disconnect();
                    requestAnimationFrame(resolve);
                }
            });

            observer.observe(document.body, { childList: true, subtree: true });

            setTimeout(() => {
                observer.disconnect();
                requestAnimationFrame(resolve);
            }, 5000);
        });
    }

    // ============================================
    // 页面加载完成后启动
    // ============================================
    function scheduleInit() {
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', window.TutorialManager.init);
        } else {
            window.TutorialManager.init();
        }
    }

    scheduleInit();
})();
