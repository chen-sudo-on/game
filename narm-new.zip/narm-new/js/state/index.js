"use strict";

// ============================================
// 状态模块 - 主入口
// ============================================

// 加载顺序依赖：initial.js -> utils.js -> proxy.js -> cleanup.js -> save.js -> index.js

// 导出模块供外部使用
window.StateUtils = StateUtils;
window.Cleanup = Cleanup;
window.SaveManager = SaveManager;
window.STATE_CONFIG = STATE_CONFIG;

// 创建并导出代理后的 state
var originalState = createInitialState();
var state = new Proxy(originalState, createStateHandler());

// 导出到全局
window.state = state;

// 便利函数：获取建筑数量（供旧代码使用）
window.getBuildingCount = StateUtils.getBuildingCount;
window.hasBuilding = StateUtils.hasBuilding;
window.getSellMultiplier = StateUtils.getSellMultiplier;
window.getWaterDurationMs = StateUtils.getWaterDurationMs;
window.isCellLit = StateUtils.isCellLit;
window.isLampPlacedAt = StateUtils.isLampPlacedAt;

// 存档相关便利函数
window.buildSaveData = SaveManager.build;
window.applySaveData = SaveManager.apply;
window.autoSaveTick = SaveManager.save;
