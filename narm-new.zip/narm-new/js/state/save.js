"use strict";

// ============================================
// 状态模块 - 存档管理
// ============================================

/**
 * 存档管理器
 */
var SaveManager = (function() {

    // 缓存最近存档数据，减少 localStorage 读取
    var lastSaveData = null;
    var saveDirty = false;

    /**
     * 构建存档数据
     */
    function build() {
        var now = Date.now();
        var data = {
            version: SAVE.version,
            savedAt: now,
            rows: CONFIG.rows,
            cols: CONFIG.cols,
            coins: state.coins,
            inventory: {
                seeds: state.inventory.seeds,
                crops: state.inventory.crops,
                foods: state.inventory.foods,
                alcohols: state.inventory.alcohols || {},
                fertilizer: state.inventory.fertilizer,
                batteries: state.inventory.batteries || 0
            },
            robot: {
                owned: !!(state.robot && state.robot.owned),
                energy: (state.robot && state.robot.energy) || 0,
                maxEnergy: (state.robot && state.robot.maxEnergy) || SHOP.robotMaxEnergy
            },
            buildingsOwned: (state.buildings && state.buildings.owned) || {},
            buildingsPlaced: Cleanup.sanitizeBuildingsPlaced(state.buildings && state.buildings.placed, StateUtils.getBuildingCount('lamp')),
            brewery: state.brewery || { slots: [] },
            orders: state.orders || { nextRefreshAt: 0, list: [] },
            recipesUnlocked: RECIPES
                .map(function(r, idx) { return { r: r, idx: idx }; })
                .filter(function(x) { return x.r && x.r.unlockPrice && x.r.unlocked; })
                .map(function(x) { return x.idx; }),
            farm: state.farm.map(function(c) {
                var waterRemaining = c.waterUntil && c.waterUntil > now ? Math.ceil((c.waterUntil - now) / 1000) : 0;
                return {
                    locked: !!c.locked,
                    type: c.type || 'wild',
                    cropId: c.cropId || null,
                    progress: c.progress || 0,
                    fertilized: !!c.fertilized,
                    harvestCount: c.harvestCount || 0,
                    weed: !!c.weed,
                    waterRemaining: c.locked ? 0 : waterRemaining,
                    emptySince: typeof c.emptySince === 'number' ? c.emptySince : (c.cropId ? 0 : now)
                };
            })
        };

        lastSaveData = data;
        saveDirty = false;
        return data;
    }

    /**
     * 保存到 localStorage
     */
    function saveToStorage() {
        var data = build();
        localStorage.setItem(SAVE.browserKey, JSON.stringify(data));
        return data;
    }

    /**
     * 从 localStorage 读取
     */
    function loadFromStorage() {
        var raw = localStorage.getItem(SAVE.browserKey);
        if (!raw) return null;
        try {
            return JSON.parse(raw);
        } catch (e) {
            console.error('[SaveManager] 解析存档失败:', e);
            return null;
        }
    }

    /**
     * 应用存档数据
     */
    function apply(data) {
        if (!data || typeof data !== 'object') {
            throw new Error('bad_save');
        }
        if (data.version !== SAVE.version) {
            throw new Error('bad_version');
        }

        var now = Date.now();

        // 基础数据
        state.coins = typeof data.coins === 'number' ? data.coins : STATE_CONFIG.initialCoins;

        // 背包
        var inv = data.inventory || {};
        state.inventory.seeds = inv.seeds && typeof inv.seeds === 'object' ? inv.seeds : {};
        state.inventory.crops = inv.crops && typeof inv.crops === 'object' ? inv.crops : {};
        state.inventory.foods = inv.foods && typeof inv.foods === 'object' ? inv.foods : {};
        state.inventory.alcohols = inv.alcohols && typeof inv.alcohols === 'object' ? inv.alcohols : {};
        state.inventory.fertilizer = typeof inv.fertilizer === 'number' ? inv.fertilizer : STATE_CONFIG.initialFertilizer;
        state.inventory.batteries = typeof inv.batteries === 'number' ? inv.batteries : STATE_CONFIG.initialBatteries;

        // 机器人
        var robot = data.robot || {};
        state.robot.owned = !!robot.owned;
        state.robot.maxEnergy = typeof robot.maxEnergy === 'number' ? robot.maxEnergy : STATE_CONFIG.robotMaxEnergy;
        state.robot.energy = typeof robot.energy === 'number' ? Math.max(0, Math.min(state.robot.maxEnergy, robot.energy)) : 0;

        // 建筑
        var ownedBuildings = data.buildingsOwned && typeof data.buildingsOwned === 'object' ? data.buildingsOwned : {};
        state.buildings.owned = ownedBuildings;
        state.buildings.sprinklerNextAt = 0;
        state.buildings.compostNextAt = 0;
        state.buildings.placed = Cleanup.sanitizeBuildingsPlaced(data.buildingsPlaced, StateUtils.getBuildingCount('lamp'));
        state.buildings.placeMode = null;

        // 酿酒
        state.brewery = Cleanup.sanitizeBreweryState(data.brewery);

        // 食谱
        var unlocked = Array.isArray(data.recipesUnlocked) ? data.recipesUnlocked : [];
        RECIPES.forEach(function(r, idx) {
            if (r && r.unlockPrice) r.unlocked = unlocked.indexOf(idx) !== -1;
        });

        // 订单
        state.orders = Cleanup.sanitizeOrdersState(data.orders, now);

        // 农田
        state.farm = Cleanup.rebuildFarm(data.farm, data.savedAt, now);

        // 离线机器人收割
        var offlineSec = Math.max(0, Math.floor((now - (typeof data.savedAt === 'number' ? data.savedAt : now)) / 1000));
        if (offlineSec > 0 && state.robot.owned && (state.robot.energy || 0) > 0) {
            var beforeEnergy = state.robot.energy || 0;
            var harvested = window.robotHarvestTick ? robotHarvestTick(true, false) : 0;
            var used = beforeEnergy - (state.robot.energy || 0);
            if (harvested > 0) showToast('离线收割：' + harvested + '（耗电 ' + used + '）', 'success');
        }

        saveDirty = false;
    }

    /**
     * 主动保存（用于手动保存）
     */
    function manualSave() {
        var data = saveToStorage();
        showToast('已保存到浏览器', 'success');
        return data;
    }

    /**
     * 检查是否有存档
     */
    function hasSave() {
        return localStorage.getItem(SAVE.browserKey) !== null;
    }

    /**
     * 清除存档
     */
    function clear() {
        localStorage.removeItem(SAVE.browserKey);
        lastSaveData = null;
        saveDirty = false;
    }

    // 导出公开接口
    return {
        build: build,
        save: saveToStorage,
        manualSave: manualSave,
        load: loadFromStorage,
        apply: apply,
        hasSave: hasSave,
        clear: clear
    };

})();
