"use strict";

// ============================================
// 状态模块 - 精简 Proxy 逻辑
// ============================================

// 配置
const PROXY_CONFIG = {
    saveThrottleMs: 1000,
    logChanges: false
};

// 保存控制
let saveTimer = null;

/**
 * 触发延迟保存（节流）
 */
function triggerDelayedSave() {
    if (saveTimer) return;

    saveTimer = setTimeout(function() {
        try {
            var data = SaveManager.build();
            localStorage.setItem(SAVE.browserKey, JSON.stringify(data));
        } catch (e) {
            console.error('[State] 保存失败:', e);
        } finally {
            saveTimer = null;
        }
    }, PROXY_CONFIG.saveThrottleMs);
}

/**
 * 记录状态变更（调试用）
 */
function logStateChange(prop, oldValue, newValue, path) {
    if (!PROXY_CONFIG.logChanges) return;

    // 跳过频繁变更
    if (prop === 'progress' || prop === 'waterUntil') {
        if (prop === 'progress' && newValue < 100) return;
    }

    var prefix = path ? '[' + path + ']' : '[state]';
    var truncatedOld = truncateForLog(oldValue);
    var truncatedNew = truncateForLog(newValue);
    console.log(prefix + ' ' + prop + ':', truncatedOld, '->', truncatedNew);
}

function truncateForLog(value, maxLen) {
    maxLen = maxLen || 100;
    if (value === null || value === undefined) return value;

    var str = typeof value === 'object' ? JSON.stringify(value) : String(value);
    if (str.length <= maxLen) return value;

    if (typeof value === 'object') {
        return '[complex object]';
    }
    return str.substring(0, maxLen) + '...';
}

// 深层代理缓存，避免重复创建
var proxyCache = new WeakMap();

/**
 * 创建深层代理（带缓存）
 */
function createDeepProxy(target, onChange) {
    // 检查是否已有代理
    if (proxyCache.has(target)) {
        return proxyCache.get(target);
    }

    var handler = {
        set: function(obj, prop, value) {
            var oldValue = obj[prop];

            // 对于深层对象，递归创建代理
            if (value !== null && typeof value === 'object' && !value._isProxied) {
                value = createDeepProxy(value, onChange);
            }

            var result = Reflect.set(obj, prop, value);

            if (result && oldValue !== value) {
                logStateChange(prop, oldValue, value, 'nested');
                onChange();
            }

            return result;
        },

        get: function(obj, prop) {
            var value = Reflect.get(obj, prop);

            // 代理标记
            if (prop === '_isProxied') return true;

            // 深层对象继续代理（带缓存）
            if (value !== null && typeof value === 'object' && !value._isProxied) {
                return createDeepProxy(value, onChange);
            }

            return value;
        },

        deleteProperty: function(obj, prop) {
            var oldValue = obj[prop];
            var result = Reflect.deleteProperty(obj, prop);

            if (result) {
                logStateChange(prop, oldValue, '[deleted]', 'nested');
                onChange();
            }

            return result;
        }
    };

    var proxy = new Proxy(target, handler);
    proxyCache.set(target, proxy);
    return proxy;
}

/**
 * 顶层 Proxy Handler
 */
function createStateHandler() {
    return {
        set: function(target, prop, value, receiver) {
            var oldValue = target[prop];
            var result = Reflect.set(target, prop, value, receiver);

            if (result && oldValue !== value) {
                logStateChange(prop, oldValue, value, 'state');
                triggerDelayedSave();
            }

            return result;
        },

        get: function(target, prop, receiver) {
            var value = Reflect.get(target, prop, receiver);

            // 对象/数组返回深层代理
            if (value !== null && typeof value === 'object') {
                if (value._isProxied) return value;
                return createDeepProxy(value, triggerDelayedSave);
            }

            return value;
        },

        deleteProperty: function(target, prop) {
            var oldValue = target[prop];
            var result = Reflect.deleteProperty(target, prop);

            if (result) {
                logStateChange(prop, oldValue, '[deleted]', 'state');
                triggerDelayedSave();
            }

            return result;
        }
    };
}

// 导出函数
window.StateProxy = {
    triggerSave: triggerDelayedSave,
    createDeepProxy: createDeepProxy,
    createHandler: createStateHandler,
    config: PROXY_CONFIG
};
