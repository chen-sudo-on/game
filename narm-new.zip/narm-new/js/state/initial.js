"use strict";

// ============================================
// 状态模块 - 初始状态定义
// ============================================

const STATE_CONFIG = {
    initialCoins: 100,
    initialFertilizer: 5,
    initialBatteries: 0,
    robotMaxEnergy: SHOP.robotMaxEnergy
};

function createInitialState() {
    return {
        coins: STATE_CONFIG.initialCoins,
        tool: 'hand',
        selectedSeed: null,
        inventory: {
            seeds: {},
            crops: {},
            foods: {},
            alcohols: {},
            fertilizer: STATE_CONFIG.initialFertilizer,
            batteries: STATE_CONFIG.initialBatteries
        },
        robot: {
            owned: false,
            energy: 0,
            maxEnergy: STATE_CONFIG.robotMaxEnergy
        },
        buildings: {
            owned: {},
            sprinklerNextAt: 0,
            compostNextAt: 0,
            placed: { lamp: [] },
            placeMode: null
        },
        brewery: { slots: [] },
        orders: { nextRefreshAt: 0, list: [] },
        farm: createInitialFarm()
    };
}

function createInitialFarm() {
    const now = Date.now();
    const n = CONFIG.rows * CONFIG.cols;
    const farm = [];

    for (let i = 0; i < n; i++) {
        const unlocked = isLandInitiallyUnlocked(i);
        farm.push({
            locked: !unlocked,
            type: 'wild',
            cropId: null,
            progress: 0,
            waterUntil: 0,
            fertilized: false,
            harvestCount: 0,
            weed: unlocked,
            emptySince: now
        });
    }

    return farm;
}

function isLandInitiallyUnlocked(idx) {
    const r = Math.floor(idx / CONFIG.cols);
    const c = idx % CONFIG.cols;
    return r >= 0 && c >= 0 && r < LAND.startRows && c < LAND.startCols;
}

function getLandUnlockPrice(idx) {
    const r = Math.floor(idx / CONFIG.cols);
    const c = idx % CONFIG.cols;
    const dr = Math.max(0, r - (LAND.startRows - 1));
    const dc = Math.max(0, c - (LAND.startCols - 1));
    const dist = dr + dc;
    const band = Math.max(1, Math.ceil(dist / 2));
    return LAND.unlockBase + LAND.unlockStep * band;
}
