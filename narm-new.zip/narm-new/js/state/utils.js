"use strict";

// ============================================
// 状态模块 - 共享工具函数
// ============================================

var StateUtils = (function() {

    /**
     * 获取建筑数量
     */
    function getBuildingCount(id) {
        var v = state.buildings && state.buildings.owned ? state.buildings.owned[id] : 0;
        if (typeof v === 'number') return Math.max(0, Math.floor(v));
        return v ? 1 : 0;
    }

    /**
     * 是否有建筑
     */
    function hasBuilding(id) {
        return getBuildingCount(id) > 0;
    }

    /**
     * 获取销售加成
     */
    function getSellMultiplier() {
        var m = 1;
        if (hasBuilding('windmill')) m *= 1.10;
        return m;
    }

    /**
     * 获取浇水持续时间（毫秒）
     */
    function getWaterDurationMs() {
        return hasBuilding('well') ? 20000 : 10000;
    }

    /**
     * 检查格子是否被照亮
     */
    function isCellLit(idx) {
        var placed = state.buildings && state.buildings.placed && Array.isArray(state.buildings.placed.lamp) ? state.buildings.placed.lamp : [];
        if (placed.length === 0) return false;
        var rc = idxToRowCol(idx);
        var radius = 2;
        for (var i = 0; i < placed.length; i++) {
            var p = placed[i];
            var prc = idxToRowCol(p);
            var d = Math.abs(prc.r - rc.r) + Math.abs(prc.c - rc.c);
            if (d <= radius) return true;
        }
        return false;
    }

    /**
     * 检查灯笼是否在指定位置
     */
    function isLampPlacedAt(idx) {
        var placed = state.buildings && state.buildings.placed && Array.isArray(state.buildings.placed.lamp) ? state.buildings.placed.lamp : [];
        return placed.indexOf(idx) !== -1;
    }

    // 导出公开接口
    return {
        getBuildingCount: getBuildingCount,
        hasBuilding: hasBuilding,
        getSellMultiplier: getSellMultiplier,
        getWaterDurationMs: getWaterDurationMs,
        isCellLit: isCellLit,
        isLampPlacedAt: isLampPlacedAt
    };

})();
