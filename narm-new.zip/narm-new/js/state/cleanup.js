"use strict";

// ============================================
// 状态模块 - 数据清理函数
// ============================================

var Cleanup = (function() {

    /**
     * 清理建筑摆放数据
     */
    function sanitizeBuildingsPlaced(raw, lampCount) {
        var max = typeof lampCount === 'number' ? Math.max(0, Math.floor(lampCount)) : 0;
        var out = { lamp: [] };
        var src = raw && typeof raw === 'object' ? raw : {};
        var lamps = Array.isArray(src.lamp) ? src.lamp : [];
        var seen = {};
        var count = 0;

        for (var i = 0; i < lamps.length; i++) {
            var v = lamps[i];
            var idx = typeof v === 'number' ? Math.floor(v) : NaN;
            if (!Number.isFinite(idx)) continue;
            if (idx < 0 || idx >= CONFIG.rows * CONFIG.cols) continue;
            if (seen[idx]) continue;

            seen[idx] = true;
            out.lamp.push(idx);
            count++;
            if (count >= max) break;
        }

        return out;
    }

    /**
     * 清理酿酒槽状态
     */
    function sanitizeBreweryState(raw) {
        var base = { slots: [] };
        var src = raw && typeof raw === 'object' ? raw : base;
        var slots = Array.isArray(src.slots) ? src.slots : [];
        var out = [];

        for (var i = 0; i < BREW.slotCount; i++) {
            var s = slots[i] && typeof slots[i] === 'object' ? slots[i] : null;
            if (!s) {
                out.push(null);
                continue;
            }

            var cropId = typeof s.cropId === 'string' ? s.cropId : null;
            var cropQty = typeof s.cropQty === 'number' ? Math.max(1, Math.floor(s.cropQty)) : 1;
            var startedAt = typeof s.startedAt === 'number' ? s.startedAt : 0;
            var doneAt = typeof s.doneAt === 'number' ? s.doneAt : 0;

            if (!cropId || !CROPS[cropId] || doneAt <= 0) {
                out.push(null);
                continue;
            }

            out.push({ cropId: cropId, cropQty: cropQty, startedAt: startedAt, doneAt: doneAt });
        }

        return { slots: out };
    }

    /**
     * 清理订单状态
     */
    function sanitizeOrdersState(raw, now) {
        var base = { nextRefreshAt: 0, list: [] };
        var src = raw && typeof raw === 'object' ? raw : base;
        var list = Array.isArray(src.list) ? src.list : [];
        var nextRefreshAt = typeof src.nextRefreshAt === 'number' ? src.nextRefreshAt : 0;

        var cleanList = list
            .filter(function(x) { return x && typeof x === 'object'; })
            .map(function(x) {
                var id = typeof x.id === 'string' ? x.id : '';
                var title = typeof x.title === 'string' ? x.title : '订单';
                var reward = typeof x.reward === 'number' ? Math.max(1, Math.floor(x.reward)) : 0;
                var createdAt = typeof x.createdAt === 'number' ? x.createdAt : now;
                var expiresAt = typeof x.expiresAt === 'number' ? x.expiresAt : 0;
                var items = Array.isArray(x.items) ? x.items : [];

                var cleanItems = items
                    .filter(function(it) { return it && typeof it === 'object'; })
                    .map(function(it) {
                        return {
                            type: it.type === 'food' || it.type === 'alcohol' ? it.type : 'crop',
                            key: typeof it.key === 'string' ? it.key : '',
                            qty: typeof it.qty === 'number' ? Math.max(1, Math.floor(it.qty)) : 1
                        };
                    })
                    .filter(function(it) { return it.key; });

                if (!id || reward <= 0 || cleanItems.length === 0) return null;
                return { id: id, title: title, reward: reward, createdAt: createdAt, expiresAt: expiresAt, items: cleanItems };
            })
            .filter(Boolean);

        var out = { nextRefreshAt: nextRefreshAt, list: cleanList };

        if (!out.nextRefreshAt || out.nextRefreshAt < 0) out.nextRefreshAt = 0;

        if (!out.list.length && now) {
            out.list = generateOrders(now, ORDERS.count);
            out.nextRefreshAt = now + ORDERS.refreshMs;
        }

        if (now && out.nextRefreshAt && now >= out.nextRefreshAt) {
            out.list = generateOrders(now, ORDERS.count);
            out.nextRefreshAt = now + ORDERS.refreshMs;
        }

        return out;
    }

    /**
     * 重建农田数据（包含离线生长计算）
     */
    function rebuildFarm(savedFarm, savedAt, now) {
        var list = Array.isArray(savedFarm) ? savedFarm : [];
        var saveHasLockedFlag = list.some(function(x) { return x && typeof x.locked === 'boolean'; });
        var targetLen = CONFIG.rows * CONFIG.cols;
        var farm = [];
        var savedAtVal = typeof savedAt === 'number' ? savedAt : now;

        for (var i = 0; i < targetLen; i++) {
            var c = list[i] || {};
            var locked = saveHasLockedFlag ? (typeof c.locked === 'boolean' ? c.locked : false) : false;

            if (locked) {
                farm.push({
                    locked: true,
                    type: 'wild',
                    cropId: null,
                    progress: 0,
                    waterUntil: 0,
                    fertilized: false,
                    harvestCount: 0,
                    weed: false,
                    emptySince: now
                });
                continue;
            }

            var waterRemainingSaved = typeof c.waterRemaining === 'number' ? c.waterRemaining : 0;
            var waterBoostSec = Math.min(waterRemainingSaved, now - savedAtVal);
            var waterRemainingNow = Math.max(0, waterRemainingSaved - (now - savedAtVal));

            var cropId = c.cropId && CROPS[c.cropId] ? c.cropId : null;
            var progress = typeof c.progress === 'number' ? Math.max(0, Math.min(100, c.progress)) : 0;
            var fertilized = !!c.fertilized;
            var harvestCount = typeof c.harvestCount === 'number' ? c.harvestCount : 0;
            var emptySinceSaved = typeof c.emptySince === 'number' ? c.emptySince : now;
            var weed = !!c.weed;
            var type = c.type === 'tilled' ? 'tilled' : 'wild';

            // 离线生长计算
            var offlineSec = Math.max(0, Math.floor((now - savedAtVal) / 1000));
            if (cropId && progress < 100 && offlineSec > 0) {
                var crop = CROPS[cropId];
                var baseMultiplier = 1;

                if (fertilized) baseMultiplier *= 1.5;
                if (crop.trait && crop.trait.type === 'speed' && typeof crop.trait.val === 'number') baseMultiplier *= crop.trait.val;
                if (crop.growth_bonus) {
                    if (crop.growth_bonus === 'night' && window.isNight) baseMultiplier *= 2;
                    if (crop.growth_bonus === 'day' && !window.isNight) baseMultiplier *= 2;
                }

                baseMultiplier *= (typeof getWeatherGrowthMultiplier === 'function' ? getWeatherGrowthMultiplier() : 1);
                var baseRate = crop.time > 0 ? (100 / crop.time) * baseMultiplier : 0;
                progress = Math.min(100, progress + baseRate * offlineSec + baseRate * waterBoostSec);
                if (progress >= 100) progress = 100;
            }

            var emptySince = cropId ? 0 : emptySinceSaved;
            if (!cropId && !weed && now - emptySince >= getWeedGrowMs()) weed = true;

            farm.push({
                locked: false,
                type: type,
                cropId: cropId,
                progress: progress,
                waterUntil: waterRemainingNow > 0 ? now + Math.ceil(waterRemainingNow) * 1000 : 0,
                fertilized: fertilized,
                harvestCount: harvestCount,
                weed: weed,
                emptySince: emptySince
            });
        }

        return farm;
    }

    // 导出公开接口
    return {
        sanitizeBuildingsPlaced: sanitizeBuildingsPlaced,
        sanitizeBreweryState: sanitizeBreweryState,
        sanitizeOrdersState: sanitizeOrdersState,
        rebuildFarm: rebuildFarm
    };

})();
