"use strict";

// --- 配置常量 ---

const CONFIG = {
    rows: 8,
    cols: 10,
    gameLoopInterval: 1000 // 1秒一次逻辑循环
};

const SAVE = {
    version: 1,
    browserKey: 'pixel-farm-save-v1'
};

const WEED = {
    growMs: 25 * 60 * 1000
};

const SHOP = {
    robotPrice: 8888,
    batteryPrice: 180,
    batteryCharge: 25,
    robotMaxEnergy: 100
};

const LAND = {
    startRows: 5,
    startCols: 5,
    unlockBase: 80,
    unlockStep: 35
};

const ORDERS = {
    refreshMs: 20 * 60 * 1000,
    count: 5
};

const BUILDINGS = [
    { id: 'well', name: '水井', emoji: '⛲', price: 1200, kind: 'functional', desc: '浇水持续更久' },
    { id: 'windmill', name: '风车', emoji: '🌬️', price: 3200, kind: 'functional', desc: '出售额外收益' },
    { id: 'sprinkler', name: '喷灌塔', emoji: '🚿', price: 4800, kind: 'functional', desc: '自动小范围浇水' },
    { id: 'compost', name: '堆肥箱', emoji: '🪣', price: 900, kind: 'functional', desc: '自动把杂草变肥料' },
    { id: 'brewery', name: '酿酒桶', emoji: '🍺', price: 2500, kind: 'functional', desc: '把作物酿成酒（很久）' },
    { id: 'fence', name: '木栅栏', emoji: '🪵', price: 280, kind: 'decor', desc: '杂草生长更慢' },
    { id: 'lamp', name: '小灯笼', emoji: '🏮', price: 600, kind: 'decor', desc: '夜晚照亮并加速附近作物' }
];

const SELFTEST = {
    enabled: new URLSearchParams(location.search).has('selftest'),
    mode: Number(new URLSearchParams(location.search).get('selftest') || '0') || 0
};
