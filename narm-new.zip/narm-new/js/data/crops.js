"use strict";

// ============================================
// 作物数据 (纯数据文件)
// ============================================
// 此文件只包含 CROPS 纯数据，不包含任何业务逻辑
// CROPS 数据结构：
// - name: 作物名称
// - emoji: 显示图标
// - price: 种子价格
// - sell: 出售价格
// - time: 生长时间（分钟）
// - seasons: 适季节 ['spring', 'summer', 'autumn', 'winter']，空数组表示四季
// - trait: 特殊属性 { label, type: 'regrow'|'bonus'|'speed', val }
// - growth_bonus: 'day'|'night' (白天/夜晚生长加速)
// - seed_drop: 收获时掉落种子 { chance, min, max }

const CROPS = {
    wheat: { name: "小麦", emoji: "🌾", price: 10, sell: 15, time: 10, seasons: ['spring', 'summer'], seed_drop: { chance: 0.4, min: 1, max: 2 } },
    lettuce: { name: "生菜", emoji: "🥬", price: 12, sell: 18, time: 12, seasons: ['spring'] },
    strawberry: { name: "草莓", emoji: "🍓", price: 50, sell: 60, time: 45, seasons: ['spring'], trait: { label: "可再生", type: "regrow", val: 20 } },
    tulip: { name: "郁金香", emoji: "🌷", price: 40, sell: 60, time: 30, seasons: ['spring'] },
    dandelion: { name: "蒲公英", emoji: "🌼", price: 20, sell: 30, time: 15, seasons: ['spring'] },
    cabbage: { name: "卷心菜", emoji: "🥬", price: 30, sell: 45, time: 35, seasons: ['spring'] },
    bamboo: { name: "竹笋", emoji: "🎍", price: 60, sell: 90, time: 50, seasons: ['spring'], trait: { label: "极速", type: "speed", val: 1.2 } },
    radish: { name: "白萝卜", emoji: "🥣", price: 25, sell: 38, time: 25, seasons: ['spring', 'winter'] },
    garlic: { name: "大蒜", emoji: "🧄", price: 35, sell: 53, time: 40, seasons: ['spring', 'summer'] },
    pea: { name: "豌豆", emoji: "🌱", price: 22, sell: 27, time: 20, seasons: ['spring'], trait: { label: "可再生", type: "regrow", val: 10 } },
    coffee: { name: "咖啡豆", emoji: "☕", price: 100, sell: 120, time: 120, seasons: ['spring', 'summer'], trait: { label: "可再生", type: "regrow", val: 40 } },
    kale: { name: "羽衣甘蓝", emoji: "🥬", price: 28, sell: 42, time: 30, seasons: ['spring'] },
    corn: { name: "玉米", emoji: "🌽", price: 15, sell: 18, time: 20, seasons: ['summer', 'autumn'], trait: { label: "可再生", type: "regrow", val: 30 }, seed_drop: { chance: 0.3, min: 1, max: 1 } },
    tomato: { name: "番茄", emoji: "🍅", price: 25, sell: 30, time: 30, seasons: ['summer'], trait: { label: "可再生", type: "regrow", val: 30 } },
    blueberry: { name: "蓝莓", emoji: "🔵", price: 80, sell: 96, time: 80, seasons: ['summer'], trait: { label: "可再生", type: "regrow", val: 50 } },
    pepper: { name: "辣椒", emoji: "🌶️", price: 35, sell: 42, time: 40, seasons: ['summer', 'autumn'], trait: { label: "可再生", type: "regrow", val: 30 } },
    melon: { name: "甜瓜", emoji: "🍈", price: 90, sell: 135, time: 80, seasons: ['summer'] },
    watermelon: { name: "西瓜", emoji: "🍉", price: 100, sell: 150, time: 90, seasons: ['summer'], trait: { label: "易丰收", type: "bonus", val: 0.2 } },
    sunflower: { name: "向日葵", emoji: "🌻", price: 180, sell: 270, time: 140, seasons: ['summer', 'autumn'], trait: { label: "种子多", type: "bonus", val: 0.5 }, seed_drop: { chance: 0.8, min: 1, max: 3 } },
    pineapple: { name: "菠萝", emoji: "🍍", price: 150, sell: 180, time: 120, seasons: ['summer'], trait: { label: "可再生", type: "regrow", val: 10 } },
    mango: { name: "芒果", emoji: "🥭", price: 110, sell: 165, time: 90, seasons: ['summer'] },
    starfruit: { name: "杨桃", emoji: "⭐", price: 130, sell: 195, time: 100, seasons: ['summer'] },
    onion: { name: "洋葱", emoji: "🧅", price: 32, sell: 48, time: 38, seasons: ['spring', 'summer'] },
    hops: { name: "啤酒花", emoji: "🍀", price: 55, sell: 66, time: 60, seasons: ['summer'], trait: { label: "可再生", type: "regrow", val: 40 } },
    carrot: { name: "胡萝卜", emoji: "🥕", price: 18, sell: 27, time: 15, seasons: ['autumn', 'spring'], trait: { label: "易丰收", type: "bonus", val: 0.3 } },
    eggplant: { name: "茄子", emoji: "🍆", price: 28, sell: 34, time: 35, seasons: ['autumn', 'summer'], trait: { label: "可再生", type: "regrow", val: 30 } },
    pumpkin: { name: "南瓜", emoji: "🎃", price: 120, sell: 180, time: 100, seasons: ['autumn'] },
    grape: { name: "葡萄", emoji: "🍇", price: 80, sell: 96, time: 70, seasons: ['autumn'], trait: { label: "可再生", type: "regrow", val: 40 } },
    sweet_potato: { name: "红薯", emoji: "🍠", price: 45, sell: 68, time: 50, seasons: ['autumn'] },
    yam: { name: "山药", emoji: "🥢", price: 50, sell: 75, time: 55, seasons: ['autumn'] },
    cranberry: { name: "蔓越莓", emoji: "🍒", price: 100, sell: 120, time: 80, seasons: ['autumn'], trait: { label: "可再生", type: "regrow", val: 20 } },
    mushroom: { name: "蘑菇", emoji: "🍄", price: 250, sell: 375, time: 180, seasons: ['autumn', 'spring'], trait: { label: "夜生", type: "speed", val: 2.0 }, growth_bonus: 'night' },
    apple: { name: "苹果", emoji: "🍎", price: 60, sell: 72, time: 60, seasons: ['autumn'], trait: { label: "可再生", type: "regrow", val: 50 } },
    bok_choy: { name: "小白菜", emoji: "🥬", price: 20, sell: 30, time: 18, seasons: ['autumn'] },
    rose: { name: "玫瑰", emoji: "🌹", price: 200, sell: 300, time: 150, seasons: ['spring', 'autumn'] },
    rice: { name: "水稻", emoji: "🌾", price: 25, sell: 38, time: 40, seasons: ['spring', 'summer', 'autumn'], seed_drop: { chance: 0.4, min: 1, max: 2 } },
    potato: { name: "土豆", emoji: "🥔", price: 20, sell: 30, time: 25, seasons: ['winter', 'spring'], trait: { label: "易丰收", type: "bonus", val: 0.4 } },
    spinach: { name: "菠菜", emoji: "🥬", price: 25, sell: 38, time: 28, seasons: ['winter'] },
    holly: { name: "冬青", emoji: "🎄", price: 150, sell: 225, time: 110, seasons: ['winter'] },
    crocus: { name: "番红花", emoji: "🌸", price: 70, sell: 105, time: 55, seasons: ['winter'] },
    snowdrop: { name: "雪花莲", emoji: "❄️", price: 90, sell: 135, time: 65, seasons: ['winter'] },
    crystal_fruit: { name: "水晶果", emoji: "💎", price: 300, sell: 450, time: 200, seasons: ['winter'], trait: { label: "夜生", type: "speed", val: 2.0 }, growth_bonus: 'night' },
    winter_root: { name: "冬根", emoji: "🍠", price: 60, sell: 90, time: 60, seasons: ['winter'] },
    ancient_fruit: { name: "上古水果", emoji: "🔮", price: 1000, sell: 1200, time: 600, seasons: [], trait: { label: "可再生", type: "regrow", val: 10 } },
    cactus: { name: "仙人掌", emoji: "🌵", price: 200, sell: 300, time: 100, seasons: [], growth_bonus: 'day' },
    mint: { name: "薄荷", emoji: "🍃", price: 30, sell: 36, time: 25, seasons: [], trait: { label: "可再生", type: "regrow", val: 20 } },
    basil: { name: "罗勒", emoji: "🌿", price: 35, sell: 53, time: 28, seasons: [] },
    rosemary: { name: "迷迭香", emoji: "🌿", price: 45, sell: 68, time: 35, seasons: [] },
    sesame: { name: "芝麻", emoji: "🌾", price: 40, sell: 60, time: 30, seasons: [] },
    oat: { name: "燕麦", emoji: "🌾", price: 38, sell: 57, time: 28, seasons: [] },
    barley: { name: "大麦", emoji: "🌾", price: 42, sell: 63, time: 32, seasons: [] },
    rye: { name: "黑麦", emoji: "🌾", price: 46, sell: 69, time: 36, seasons: ['autumn'] },
    flax: { name: "亚麻", emoji: "🌾", price: 50, sell: 75, time: 40, seasons: [] },
    clover: { name: "三叶草", emoji: "🍀", price: 55, sell: 83, time: 35, seasons: [], trait: { label: "易丰收", type: "bonus", val: 0.3 } },
    sugarcane: { name: "甘蔗", emoji: "🎋", price: 60, sell: 90, time: 60, seasons: ['summer', 'autumn'] },
    coconut: { name: "椰子", emoji: "🥥", price: 80, sell: 120, time: 60, seasons: [] },
    cacao: { name: "可可豆", emoji: "🍫", price: 120, sell: 180, time: 90, seasons: [] },
    gem_berry: { name: "宝石甜莓", emoji: "💎", price: 2000, sell: 3000, time: 1000, seasons: ['autumn'] },
    tea_bush: { name: "茶叶", emoji: "🍵", price: 500, sell: 600, time: 300, seasons: ['spring', 'summer', 'autumn'], trait: { label: "可再生", type: "regrow", val: 100 } },
    banana: { name: "香蕉", emoji: "🍌", price: 95, sell: 114, time: 85, seasons: ['summer'], trait: { label: "可再生", type: "regrow", val: 40 } },
    orange: { name: "橘子", emoji: "🍊", price: 68, sell: 82, time: 62, seasons: ['summer'], trait: { label: "可再生", type: "regrow", val: 50 } },
    peach: { name: "桃子", emoji: "🍑", price: 65, sell: 78, time: 65, seasons: ['summer'], trait: { label: "可再生", type: "regrow", val: 50 } },
    cherry: { name: "樱桃", emoji: "🍒", price: 70, sell: 84, time: 55, seasons: ['spring'], trait: { label: "可再生", type: "regrow", val: 50 } },
    lemon: { name: "柠檬", emoji: "🍋", price: 85, sell: 102, time: 75, seasons: ['summer'], trait: { label: "可再生", type: "regrow", val: 40 } },
    cucumber: { name: "黄瓜", emoji: "🥒", price: 30, sell: 36, time: 32, seasons: ['summer', 'autumn'], trait: { label: "可再生", type: "regrow", val: 30 } },
    weed: { name: "杂草", emoji: "🌿", price: 0, sell: 0.5, time: 0, seasons: [] }
};

// 为所有可再生作物添加最大收获次数（后处理逻辑）
for (let k in CROPS) {
    if (CROPS[k].trait && CROPS[k].trait.type === 'regrow') {
        CROPS[k].trait.max_harvest = 5; // 默认5次
    }
}
