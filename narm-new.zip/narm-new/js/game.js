/**
 * 游戏状态管理器 - 简单版
 * 用于统一管理游戏 UI 状态，不涉及玩法逻辑
 *
 * 使用方法：
 * - 读取状态：GameState.currentTool, GameState.ui.leftPanelOpen
 * - 修改状态：GameState.setTool('hoe'), GameState.toggleLeftPanel()
 */

const GameState = {
    // 游戏是否已初始化
    isReady: false,

    // 框架版本
    version: '1.0.1',

    ui: {
        leftPanelOpen: false,
        rightPanelOpen: false,
        currentTab: 'shop'
    },

    time: {
        isNight: false,
        currentSeason: 'spring',
        lastUpdate: 0
    },

    // ==================== 初始化 ====================

    /**
     * 初始化 GameState
     * 在游戏 init() 完成时调用
     */
    init() {
        if (this.isReady) return;

        // 从 state 同步初始状态
        this.syncFromState();

        this.isReady = true;
        console.log('[GameState] 游戏状态管理器已初始化 v' + this.version);
    },

    /**
     * 从全局 state 同步状态
     */
    syncFromState() {
        if (typeof state === 'undefined') return;

        // 同步工具状态
        this.currentTool = state.tool || 'hand';
        this.selectedSeed = state.selectedSeed || null;

        // 同步时间状态
        this.time.isNight = window.isNight || false;
        this.time.currentSeason = window.currentSeason || 'spring';
        this.time.lastUpdate = Date.now();
    },

    /**
     * 与 state 保持同步（供外部调用）
     */
    sync() {
        this.syncFromState();
    },

    // ==================== 工具操作 ====================

    // 当前选中的工具（与 state.tool 同步）
    currentTool: 'hand',

    // 当前选中的种子（与 state.selectedSeed 同步）
    selectedSeed: null,

    /**
     * 设置当前工具
     * @param {string} toolName - 工具名称: hand, hoe, water, scythe, fertilizer, basket, shovel
     */
    setTool(toolName) {
        this.currentTool = toolName;
        this.selectedSeed = null;
    },

    /**
     * 选中种子进行种植
     * @param {string} seedId - 种子 ID
     */
    selectSeed(seedId) {
        this.selectedSeed = seedId;
        this.currentTool = 'hand';
    },

    /**
     * 清空当前选择（种子或工具）
     */
    clearSelection() {
        this.selectedSeed = null;
        this.currentTool = 'hand';
    },

    // ==================== 面板操作 ====================

    /**
     * 切换左侧面板开关状态
     * @returns {boolean} 切换后的状态
     */
    toggleLeftPanel() {
        this.ui.leftPanelOpen = !this.ui.leftPanelOpen;
        return this.ui.leftPanelOpen;
    },

    /**
     * 切换右侧面板开关状态
     * @returns {boolean} 切换后的状态
     */
    toggleRightPanel() {
        this.ui.rightPanelOpen = !this.ui.rightPanelOpen;
        return this.ui.rightPanelOpen;
    },

    /**
     * 打开左侧面板
     */
    openLeftPanel() {
        this.ui.leftPanelOpen = true;
    },

    /**
     * 关闭左侧面板
     */
    closeLeftPanel() {
        this.ui.leftPanelOpen = false;
    },

    /**
     * 打开右侧面板
     */
    openRightPanel() {
        this.ui.rightPanelOpen = true;
    },

    /**
     * 关闭右侧面板
     */
    closeRightPanel() {
        this.ui.rightPanelOpen = false;
    },

    /**
     * 关闭所有面板
     */
    closeAllPanels() {
        this.ui.leftPanelOpen = false;
        this.ui.rightPanelOpen = false;
    },

    // ==================== 标签页操作 ====================

    /**
     * 切换标签页
     * @param {string} tabName - 标签名: shop, inventory, orders
     */
    switchTab(tabName) {
        this.ui.currentTab = tabName;
    },

    // ==================== 时间操作 ====================

    /**
     * 更新时间状态
     * @param {boolean} isNight - 是否夜间
     * @param {string} season - 季节: spring, summer, autumn, winter
     */
    updateTime(isNight, season) {
        this.time.isNight = isNight;
        this.time.currentSeason = season;
        this.time.lastUpdate = Date.now();
    },

    // ==================== 状态查询 ====================

    /**
     * 获取当前工具显示名称
     * @returns {string}
     */
    getToolLabel() {
        const toolNames = {
            hand: '查看',
            hoe: '开垦',
            water: '浇水',
            scythe: '收获',
            fertilizer: '施肥',
            basket: '收集',
            shovel: '铲除'
        };

        if (this.selectedSeed && CROPS[this.selectedSeed]) {
            return '种植' + CROPS[this.selectedSeed].name;
        }
        return toolNames[this.currentTool] || '查看';
    },

    /**
     * 获取当前选中物品的显示文本
     * @returns {string}
     */
    getSelectionLabel() {
        if (this.selectedSeed && CROPS[this.selectedSeed]) {
            return CROPS[this.selectedSeed].name + '种子';
        }
        return this.getToolLabel();
    },

    // ==================== 调试功能 ====================

    /**
     * 获取状态快照（用于调试）
     * @returns {object}
     */
    getSnapshot() {
        return {
            isReady: this.isReady,
            version: this.version,
            currentTool: this.currentTool,
            selectedSeed: this.selectedSeed,
            ui: { ...this.ui },
            time: { ...this.time },
            timestamp: Date.now()
        };
    },

    /**
     * 打印当前状态到控制台
     */
    dump() {
        console.log('=== GameState Dump ===');
        console.log(this.getSnapshot());
        console.log('======================');
    }
};

// 挂载到全局
window.GameState = GameState;

/**
 * 自动初始化 GameState
 * 在 DOM 加载完成后，通过 events.js 的 init() 调用 GameState.init()
 * 这样可以确保 state 和所有游戏组件都已准备好
 */
