"use strict";

// --- 音频相关 ---

// 音频状态
const audioState = {
    enabled: true,
    ctx: null,
    master: null,
    unlocked: false
};

// 确保音频上下文
function ensureAudioContext() {
    if (audioState.ctx) return audioState.ctx;
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return null;
    const ctx = new AC();
    const master = ctx.createGain();
    master.gain.value = 0.22;
    master.connect(ctx.destination);
    audioState.ctx = ctx;
    audioState.master = master;
    return ctx;
}

// 解锁音频一次
function unlockAudioOnce() {
    if (audioState.unlocked) return;
    audioState.unlocked = true;
    try {
        const ctx = ensureAudioContext();
        if (!ctx) return;
        if (ctx.state === 'suspended') ctx.resume().catch(() => {});
        playSound('coin');
    } catch {}
}

// 加载音频设置
function loadAudioSetting() {
    try {
        const v = localStorage.getItem('pixel-farm-audio-enabled');
        if (v === '0') audioState.enabled = false;
        if (v === '1') audioState.enabled = true;
    } catch {}
}

// 渲染音频开关按钮
function renderAudioToggle() {
    const btn = document.getElementById('audio-toggle');
    if (!btn) return;
    const on = !!audioState.enabled;
    btn.innerText = on ? '🔊' : '🔇';
    btn.title = on ? '音效：开' : '音效：关';
    btn.setAttribute('aria-label', btn.title);
}

// 切换音频
function toggleAudio() {
    audioState.enabled = !audioState.enabled;
    try {
        localStorage.setItem('pixel-farm-audio-enabled', audioState.enabled ? '1' : '0');
    } catch {}
    renderAudioToggle();
    if (audioState.enabled) {
        unlockAudioOnce();
        playSound('coin');
        showToast('音效已开启', 'success');
    } else {
        showToast('音效已关闭');
    }
}

// 播放音效
function playSound(type) {
    try {
        if (!audioState.enabled) return;
        const ctx = ensureAudioContext();
        if (!ctx) return;
        if (ctx.state === 'suspended') {
            ctx.resume().catch(() => {});
        }
        const t0 = ctx.currentTime + 0.001;

        if (type === 'dig') {
            playBeep(t0, { freq: 160, toFreq: 90, dur: 0.12, gain: 0.14, wave: 'square' });
            playBeep(t0 + 0.03, { freq: 140, toFreq: 70, dur: 0.10, gain: 0.11, wave: 'square' });
            return;
        }
        if (type === 'water') {
            playBeep(t0, { freq: 520, toFreq: 380, dur: 0.08, gain: 0.10, wave: 'sine' });
            playBeep(t0 + 0.06, { freq: 460, toFreq: 300, dur: 0.09, gain: 0.08, wave: 'sine' });
            return;
        }
        if (type === 'plant') {
            playBeep(t0, { freq: 330, toFreq: 520, dur: 0.10, gain: 0.10, wave: 'triangle' });
            playBeep(t0 + 0.09, { freq: 660, toFreq: 760, dur: 0.05, gain: 0.07, wave: 'triangle' });
            return;
        }
        if (type === 'harvest') {
            playBeep(t0, { freq: 740, toFreq: 980, dur: 0.06, gain: 0.10, wave: 'triangle' });
            playBeep(t0 + 0.05, { freq: 980, toFreq: 1175, dur: 0.06, gain: 0.09, wave: 'triangle' });
            return;
        }
        if (type === 'buy') {
            playBeep(t0, { freq: 520, toFreq: 780, dur: 0.07, gain: 0.10, wave: 'sine' });
            playBeep(t0 + 0.07, { freq: 780, toFreq: 1040, dur: 0.07, gain: 0.10, wave: 'sine' });
            return;
        }
        if (type === 'coin') {
            playBeep(t0, { freq: 1040, toFreq: 1560, dur: 0.05, gain: 0.08, wave: 'sine' });
            playBeep(t0 + 0.05, { freq: 1560, toFreq: 2080, dur: 0.04, gain: 0.06, wave: 'sine' });
            return;
        }
        if (type === 'craft') {
            playBeep(t0, { freq: 392, toFreq: 523, dur: 0.08, gain: 0.10, wave: 'triangle' });
            playBeep(t0 + 0.08, { freq: 523, toFreq: 659, dur: 0.08, gain: 0.10, wave: 'triangle' });
            playBeep(t0 + 0.16, { freq: 659, toFreq: 784, dur: 0.10, gain: 0.10, wave: 'triangle' });
            return;
        }
    } catch {}
}

// 播放哔哔声
function playBeep(startAt, { freq, toFreq, dur, gain, wave }) {
    const ctx = audioState.ctx;
    const master = audioState.master;
    if (!ctx || !master) return;

    const o = ctx.createOscillator();
    const g = ctx.createGain();

    o.type = wave || 'sine';
    o.frequency.setValueAtTime(freq, startAt);
    if (typeof toFreq === 'number' && toFreq > 0) {
        o.frequency.exponentialRampToValueAtTime(Math.max(1, toFreq), startAt + Math.max(0.01, dur));
    }

    const peak = Math.max(0, Math.min(1, gain || 0.1));
    const a = 0.006;
    const r = Math.max(0.01, dur * 0.45);
    g.gain.setValueAtTime(0.0001, startAt);
    g.gain.exponentialRampToValueAtTime(Math.max(0.0002, peak), startAt + a);
    g.gain.exponentialRampToValueAtTime(0.0001, startAt + Math.max(a + 0.01, dur - r));
    g.gain.exponentialRampToValueAtTime(0.0001, startAt + dur);

    o.connect(g);
    g.connect(master);

    o.start(startAt);
    o.stop(startAt + dur + 0.02);
    o.onended = () => {
        try { o.disconnect(); } catch {}
        try { g.disconnect(); } catch {}
    };
}

// 导出到全局
window.audioState = audioState;
window.ensureAudioContext = ensureAudioContext;
window.unlockAudioOnce = unlockAudioOnce;
window.loadAudioSetting = loadAudioSetting;
window.renderAudioToggle = renderAudioToggle;
window.toggleAudio = toggleAudio;
window.playSound = playSound;
window.playBeep = playBeep;

// 存档文件输入处理
window.addEventListener('load', () => {
    const input = document.getElementById('save-file-input');
    if (!input) return;
    input.addEventListener('change', (e) => {
        const file = e.target.files && e.target.files[0];
        if (file) handleImportFile(file);
    });
});

// 解锁音频
window.addEventListener('pointerdown', unlockAudioOnce, { once: true, passive: true });
window.addEventListener('keydown', unlockAudioOnce, { once: true, passive: true });
