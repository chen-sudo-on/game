"use strict";

// ============================================
// 工具函数：坐标转换
// ============================================

function idxToRowCol(idx) {
    const r = Math.floor(idx / CONFIG.cols);
    const c = idx % CONFIG.cols;
    return { r, c };
}

function isLandInitiallyUnlocked(idx) {
    const { r, c } = idxToRowCol(idx);
    return r >= 0 && c >= 0 && r < LAND.startRows && c < LAND.startCols;
}

function getLandUnlockPrice(idx) {
    const { r, c } = idxToRowCol(idx);
    const dr = Math.max(0, r - (LAND.startRows - 1));
    const dc = Math.max(0, c - (LAND.startCols - 1));
    const dist = dr + dc;
    const band = Math.max(1, Math.ceil(dist / 2));
    return LAND.unlockBase + LAND.unlockStep * band;
}

// ============================================
// 依赖函数（从 utils.js 迁移，因加载顺序需要）
// ============================================

/**
 * 获取建筑数量
 */
function getBuildingCount(id) {
    const v = state.buildings && state.buildings.owned ? state.buildings.owned[id] : 0;
    if (typeof v === 'number') return Math.max(0, Math.floor(v));
    return v ? 1 : 0;
}

// ============================================
// 创建初始农场
// ============================================

function createInitialFarm() {
    const now = Date.now();
    const n = CONFIG.rows * CONFIG.cols;
    const farm = [];

    for (let i = 0; i < n; i++) {
        const unlocked = isLandInitiallyUnlocked(i);
        farm.push({
            locked: !unlocked,
            type: 'wild',
            cropId: null,
            progress: 0,
            waterUntil: 0,
            fertilized: false,
            harvestCount: 0,
            weed: unlocked,
            emptySince: now
        });
    }

    return farm;
}

// ============================================
// 数据清理函数（从 index_backup.html 迁移）
// ============================================

/**
 * 清理建筑摆放数据
 */
function sanitizeBuildingsPlaced(raw, lampCount) {
    const max = typeof lampCount === 'number' ? Math.max(0, Math.floor(lampCount)) : 0;
    const out = { lamp: [] };
    const src = raw && typeof raw === 'object' ? raw : {};
    const lamps = Array.isArray(src.lamp) ? src.lamp : [];
    const seen = new Set();

    for (const v of lamps) {
        const idx = typeof v === 'number' ? Math.floor(v) : NaN;
        if (!Number.isFinite(idx)) continue;
        if (idx < 0 || idx >= CONFIG.rows * CONFIG.cols) continue;
        if (seen.has(idx)) continue;
        seen.add(idx);
        out.lamp.push(idx);
        if (out.lamp.length >= max) break;
    }

    return out;
}

/**
 * 清理酿酒槽状态
 */
function sanitizeBreweryState(raw) {
    const base = { slots: [] };
    const src = raw && typeof raw === 'object' ? raw : base;
    const slots = Array.isArray(src.slots) ? src.slots : [];
    const out = [];

    for (let i = 0; i < BREW.slotCount; i++) {
        const s = slots[i] && typeof slots[i] === 'object' ? slots[i] : null;
        if (!s) {
            out.push(null);
            continue;
        }
        const cropId = typeof s.cropId === 'string' ? s.cropId : null;
        const cropQty = typeof s.cropQty === 'number' ? Math.max(1, Math.floor(s.cropQty)) : 1;
        const startedAt = typeof s.startedAt === 'number' ? s.startedAt : 0;
        const doneAt = typeof s.doneAt === 'number' ? s.doneAt : 0;

        if (!cropId || !CROPS[cropId] || doneAt <= 0) {
            out.push(null);
            continue;
        }

        out.push({ cropId, cropQty, startedAt, doneAt });
    }

    return { slots: out };
}

/**
 * 清理订单状态
 */
function sanitizeOrdersState(raw, now) {
    const base = { nextRefreshAt: 0, list: [] };
    const src = raw && typeof raw === 'object' ? raw : base;
    const list = Array.isArray(src.list) ? src.list : [];
    const nextRefreshAt = typeof src.nextRefreshAt === 'number' ? src.nextRefreshAt : 0;

    const cleanList = list
        .filter(x => x && typeof x === 'object')
        .map(x => {
            const id = typeof x.id === 'string' ? x.id : '';
            const title = typeof x.title === 'string' ? x.title : '订单';
            const reward = typeof x.reward === 'number' ? Math.max(1, Math.floor(x.reward)) : 0;
            const createdAt = typeof x.createdAt === 'number' ? x.createdAt : now;
            const expiresAt = typeof x.expiresAt === 'number' ? x.expiresAt : 0;
            const items = Array.isArray(x.items) ? x.items : [];
            const cleanItems = items
                .filter(it => it && typeof it === 'object')
                .map(it => ({
                    type: it.type === 'food' || it.type === 'alcohol' ? it.type : 'crop',
                    key: typeof it.key === 'string' ? it.key : '',
                    qty: typeof it.qty === 'number' ? Math.max(1, Math.floor(it.qty)) : 1
                }))
                .filter(it => it.key);
            if (!id || reward <= 0 || cleanItems.length === 0) return null;
            return { id, title, reward, createdAt, expiresAt, items: cleanItems };
        })
        .filter(Boolean);

    const out = { nextRefreshAt, list: cleanList };

    if (!out.nextRefreshAt || out.nextRefreshAt < 0) out.nextRefreshAt = 0;

    if (!out.list.length && now) {
        out.list = generateOrders(now, ORDERS.count);
        out.nextRefreshAt = now + ORDERS.refreshMs;
    }

    if (now && out.nextRefreshAt && now >= out.nextRefreshAt) {
        out.list = generateOrders(now, ORDERS.count);
        out.nextRefreshAt = now + ORDERS.refreshMs;
    }

    return out;
}

// ============================================
// 游戏状态（使用 Proxy 包装）
// ============================================

// 原始状态数据
let originalState = {
    coins: 100,
    tool: 'hand',
    selectedSeed: null,
    inventory: {
        seeds: {},
        crops: {},
        foods: {},
        alcohols: {},
        fertilizer: 5,
        batteries: 0
    },
    robot: {
        owned: false,
        energy: 0,
        maxEnergy: SHOP.robotMaxEnergy
    },
    buildings: {
        owned: {},
        sprinklerNextAt: 0,
        compostNextAt: 0,
        placed: {
            lamp: []
        },
        placeMode: null
    },
    brewery: {
        slots: []
    },
    orders: {
        nextRefreshAt: 0,
        list: []
    },
    farm: createInitialFarm()
};

// 自动保存节流控制
let saveTimer = null;
let saveThrottleMs = 1000;

// ============================================
// 日志和日志辅助函数
// ============================================

function logStateChange(prop, oldValue, newValue, path) {
    // 避免打印过于频繁的变更（如 progress 变化）
    if (prop === 'progress' || prop === 'waterUntil') {
        if (prop === 'progress' && newValue < 100) return;
    }

    const prefix = path ? `[${path}]` : '[state]';
    const truncatedOld = truncateForLog(oldValue);
    const truncatedNew = truncateForLog(newValue);
    console.log(`${prefix} ${prop}:`, truncatedOld, '→', truncatedNew);
}

function truncateForLog(value, maxLen = 100) {
    if (value === null || value === undefined) return value;

    const str = typeof value === 'object' ? JSON.stringify(value) : String(value);
    if (str.length <= maxLen) return value;

    if (typeof value === 'object') {
        return '[complex object]';
    }
    return str.substring(0, maxLen) + '...';
}

// ============================================
// Proxy 处理器
// ============================================

// 深层代理工厂函数
function createDeepProxy(target, onChange) {
    const handler = {
        set(obj, prop, value) {
            const oldValue = obj[prop];
            const path = `[nested] ${prop}`;

            // 对于深层对象，递归创建代理
            if (value !== null && typeof value === 'object' && !value._isProxied) {
                value = createDeepProxy(value, onChange);
            }

            const result = Reflect.set(obj, prop, value);

            if (result && oldValue !== value) {
                logStateChange(prop, oldValue, value, path);
                onChange();
            }

            return result;
        },

        get(obj, prop) {
            const value = Reflect.get(obj, prop);

            // 代理标记，用于避免重复代理
            if (prop === '_isProxied') return true;

            // 深层对象继续代理
            if (value !== null && typeof value === 'object' && !value._isProxied) {
                return createDeepProxy(value, onChange);
            }

            return value;
        },

        deleteProperty(obj, prop) {
            const oldValue = obj[prop];
            const result = Reflect.deleteProperty(obj, prop);

            if (result) {
                logStateChange(prop, oldValue, '[deleted]', '[nested]');
                onChange();
            }

            return result;
        }
    };

    return new Proxy(target, handler);
}

// Proxy 的 handler
const stateHandler = {
    set(target, prop, value, receiver) {
        const oldValue = target[prop];
        const path = prop;

        // 设置新值
        const result = Reflect.set(target, prop, value, receiver);

        // 打印变更日志
        logStateChange(prop, oldValue, value, path);

        // 触发延迟保存
        triggerDelayedSave();

        return result;
    },

    get(target, prop, receiver) {
        const value = Reflect.get(target, prop, receiver);

        // 如果获取的是对象/数组，返回包装后的 Proxy 以支持深层追踪
        if (value !== null && typeof value === 'object') {
            // 检查是否已经是被代理的对象
            if (value._isProxied) return value;

            // 返回深层代理
            return createDeepProxy(value, () => {
                // 深层变更也触发保存
                triggerDelayedSave();
            });
        }

        return value;
    },

    deleteProperty(target, prop) {
        const oldValue = target[prop];
        const result = Reflect.deleteProperty(target, prop);

        if (result) {
            logStateChange(prop, oldValue, '[deleted]', '[state]');
            triggerDelayedSave();
        }

        return result;
    }
};

// ============================================
// 保存功能
// ============================================

/**
 * 触发延迟保存（用于节流）
 */
function triggerDelayedSave() {
    if (saveTimer) return;

    saveTimer = setTimeout(() => {
        try {
            const data = buildSaveData();
            localStorage.setItem(SAVE.browserKey, JSON.stringify(data));
        } catch (e) {
            console.error('[State] 保存失败:', e);
        } finally {
            saveTimer = null;
        }
    }, saveThrottleMs);
}

/**
 * 构建存档数据
 */
function buildSaveData() {
    const now = Date.now();
    return {
        version: SAVE.version,
        savedAt: now,
        rows: CONFIG.rows,
        cols: CONFIG.cols,
        coins: state.coins,
        inventory: {
            seeds: state.inventory.seeds,
            crops: state.inventory.crops,
            foods: state.inventory.foods,
            alcohols: state.inventory.alcohols || {},
            fertilizer: state.inventory.fertilizer,
            batteries: state.inventory.batteries || 0
        },
        robot: {
            owned: !!(state.robot && state.robot.owned),
            energy: (state.robot && state.robot.energy) || 0,
            maxEnergy: (state.robot && state.robot.maxEnergy) || SHOP.robotMaxEnergy
        },
        buildingsOwned: (state.buildings && state.buildings.owned) || {},
        buildingsPlaced: (state.buildings && state.buildings.placed) || { lamp: [] },
        brewery: state.brewery || { slots: [] },
        orders: state.orders || { nextRefreshAt: 0, list: [] },
        recipesUnlocked: RECIPES
            .map((r, idx) => ({ r, idx }))
            .filter(x => x.r && x.r.unlockPrice && x.r.unlocked)
            .map(x => x.idx),
        farm: state.farm.map(c => {
            const waterRemaining = c.waterUntil && c.waterUntil > now ? Math.ceil((c.waterUntil - now) / 1000) : 0;
            return {
                locked: !!c.locked,
                type: c.type || 'wild',
                cropId: c.cropId || null,
                progress: c.progress || 0,
                fertilized: !!c.fertilized,
                harvestCount: c.harvestCount || 0,
                weed: !!c.weed,
                waterRemaining: c.locked ? 0 : waterRemaining,
                emptySince: typeof c.emptySince === 'number' ? c.emptySince : (c.cropId ? 0 : now)
            };
        })
    };
}

/**
 * 应用存档数据
 */
function applySaveData(data) {
    if (!data || typeof data !== 'object') throw new Error('bad_save');
    if (data.version !== SAVE.version) throw new Error('bad_version');

    state.coins = typeof data.coins === 'number' ? data.coins : 100;

    // 背包
    const inv = data.inventory || {};
    state.inventory.seeds = inv.seeds && typeof inv.seeds === 'object' ? inv.seeds : {};
    state.inventory.crops = inv.crops && typeof inv.crops === 'object' ? inv.crops : {};
    state.inventory.foods = inv.foods && typeof inv.foods === 'object' ? inv.foods : {};
    state.inventory.alcohols = inv.alcohols && typeof inv.alcohols === 'object' ? inv.alcohols : {};
    state.inventory.fertilizer = typeof inv.fertilizer === 'number' ? inv.fertilizer : (state.inventory.fertilizer || 0);
    state.inventory.batteries = typeof inv.batteries === 'number' ? inv.batteries : (state.inventory.batteries || 0);

    // 机器人
    const robot = data.robot || {};
    state.robot.owned = !!robot.owned;
    state.robot.maxEnergy = typeof robot.maxEnergy === 'number' ? robot.maxEnergy : SHOP.robotMaxEnergy;
    state.robot.energy = typeof robot.energy === 'number' ? Math.max(0, Math.min(state.robot.maxEnergy, robot.energy)) : 0;

    // 建筑
    const ownedBuildings = data.buildingsOwned && typeof data.buildingsOwned === 'object' ? data.buildingsOwned : {};
    state.buildings.owned = ownedBuildings;
    state.buildings.sprinklerNextAt = 0;
    state.buildings.compostNextAt = 0;
    state.buildings.placed = sanitizeBuildingsPlaced(data.buildingsPlaced, getBuildingCount('lamp'));
    state.buildings.placeMode = null;

    // 酿酒
    state.brewery = sanitizeBreweryState(data.brewery);

    // 食谱
    const unlocked = Array.isArray(data.recipesUnlocked) ? data.recipesUnlocked : [];
    RECIPES.forEach((r, idx) => {
        if (r && r.unlockPrice) r.unlocked = unlocked.includes(idx);
    });

    // 订单
    const now = Date.now();
    const savedAt = typeof data.savedAt === 'number' ? data.savedAt : now;
    state.orders = sanitizeOrdersState(data.orders, now);

    // 农田
    const list = Array.isArray(data.farm) ? data.farm : [];
    const saveHasLockedFlag = list.some(x => x && typeof x.locked === 'boolean');
    const targetLen = CONFIG.rows * CONFIG.cols;
    const farm = [];

    for (let i = 0; i < targetLen; i++) {
        const c = list[i] || {};
        const locked = saveHasLockedFlag ? (typeof c.locked === 'boolean' ? c.locked : false) : false;

        if (locked) {
            farm.push({
                locked: true,
                type: 'wild',
                cropId: null,
                progress: 0,
                waterUntil: 0,
                fertilized: false,
                harvestCount: 0,
                weed: false,
                emptySince: now
            });
            continue;
        }

        const waterRemainingSaved = typeof c.waterRemaining === 'number' ? c.waterRemaining : 0;
        const waterBoostSec = Math.min(waterRemainingSaved, now - savedAt);
        const waterRemainingNow = Math.max(0, waterRemainingSaved - (now - savedAt));

        const cropId = c.cropId && CROPS[c.cropId] ? c.cropId : null;
        let progress = typeof c.progress === 'number' ? Math.max(0, Math.min(100, c.progress)) : 0;
        const fertilized = !!c.fertilized;
        const harvestCount = typeof c.harvestCount === 'number' ? c.harvestCount : 0;
        const emptySinceSaved = typeof c.emptySince === 'number' ? c.emptySince : now;
        let weed = !!c.weed;
        const type = c.type === 'tilled' ? 'tilled' : 'wild';

        // 离线生长计算
        const offlineSec = Math.max(0, Math.floor((now - savedAt) / 1000));
        if (cropId && progress < 100 && offlineSec > 0) {
            const crop = CROPS[cropId];
            let baseMultiplier = 1;

            if (fertilized) baseMultiplier *= 1.5;
            if (crop.trait && crop.trait.type === 'speed' && typeof crop.trait.val === 'number') baseMultiplier *= crop.trait.val;
            if (crop.growth_bonus) {
                if (crop.growth_bonus === 'night' && window.isNight) baseMultiplier *= 2;
                if (crop.growth_bonus === 'day' && !window.isNight) baseMultiplier *= 2;
            }

            baseMultiplier *= getWeatherGrowthMultiplier();
            const baseRate = crop.time > 0 ? (100 / crop.time) * baseMultiplier : 0;
            progress = Math.min(100, progress + baseRate * offlineSec + baseRate * waterBoostSec);
            if (progress >= 100) progress = 100;
        }

        const emptySince = cropId ? 0 : emptySinceSaved;
        if (!cropId && !weed && now - emptySince >= getWeedGrowMs()) weed = true;

        farm.push({
            locked: false,
            type,
            cropId,
            progress,
            waterUntil: waterRemainingNow > 0 ? now + Math.ceil(waterRemainingNow) * 1000 : 0,
            fertilized,
            harvestCount,
            weed,
            emptySince
        });
    }

    state.farm = farm;

    // 离线机器人收割
    const offlineSec = Math.max(0, Math.floor((now - savedAt) / 1000));
    if (offlineSec > 0 && state.robot.owned && (state.robot.energy || 0) > 0) {
        const beforeEnergy = state.robot.energy || 0;
        const harvested = robotHarvestTick(true, false);
        const used = beforeEnergy - (state.robot.energy || 0);
        if (harvested > 0) showToast(`离线收割：${harvested}（耗电 ${used}）`, 'success');
    }
}

/**
 * 自动保存（每秒）
 */
function autoSaveTick() {
    const data = buildSaveData();
    localStorage.setItem(SAVE.browserKey, JSON.stringify(data));
}

// ============================================
// 创建并导出代理后的 state
// ============================================

const state = new Proxy(originalState, stateHandler);
