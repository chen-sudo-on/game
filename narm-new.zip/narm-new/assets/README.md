# Assets 文件夹说明

本文件夹用于存放游戏的外部资源文件。

## 文件夹结构

```
assets/
├── images/          # 图片资源（作物图、背景等）
│   ├── crops/       # 作物图片
│   ├── backgrounds/ # 背景图片
│   └── ui/          # UI 图片（按钮、图标等）
├── audio/           # 音效和音乐
│   ├── music/       # 背景音乐
│   └── sfx/         # 音效文件
└── icons/           # 图标资源
```

## 使用方法

1. **图片资源**：放在 `images/` 文件夹下，在 CSS 或 JS 中引用
   ```
   assets/images/crops/wheat.png
   ```

2. **音效资源**：放在 `audio/` 文件夹下
   ```
   assets/audio/sfx/click.mp3
   assets/audio/music/bgm.mp3
   ```

3. **图标资源**：放在 `icons/` 文件夹下
   ```
   assets/icons/favicon.ico
   ```

## 注意事项

- 图片推荐格式：PNG（支持透明）、SVG（矢量图）
- 音效推荐格式：MP3、OGG、WAV
- 大文件请压缩后使用
- 可以在 `images/` 下创建子分类组织资源

## 示例

```javascript
// 在 JS 中引用图片
const cropImage = 'assets/images/crops/tomato.png';

// 在 CSS 中引用图片
.my-element {
    background-image: url('assets/images/backgrounds/farm.png');
}
```
